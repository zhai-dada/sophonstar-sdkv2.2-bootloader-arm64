import json
import os
import base64
import time
import datetime
import requests
import flask
import shutil
from non_volatile_config import NonVolatileConfigParser
import re
import hashlib
import tarfile
import zipfile
import threading
import subprocess
import socket

from threading import Thread, Lock
from http import HTTPStatus
from flask import request,jsonify
from flask import Blueprint, render_template, send_from_directory
from flask.views import MethodView
# from sophonface import Mode, DEFAULT_MODE,Product
from distutils.util import strtobool
from requests.exceptions import ConnectionError
import psutil
from system_misc import make_error_response,ErrorResponseType,get_product
from running_state import run_in_docker
import logger
from system_factory import SystemFunction
from system_config import ConfigDataSingletone

build_info_path = '/opt/data/buildinfo.txt'
config_ntp = '/etc/systemd/timesyncd.conf'
device_type_info = '/sys/kernel/debug/memblock/memory'
ota_config_path = '/data/ota/otaconfig.ini'

_logger = logger.getLogger("SystemServer")
system_fun = SystemFunction()

def fun_restart_timer():
    print('#####reboot####')
    execShell("reboot")

def restart_service():
    print('#####delya reboot####')
    timer = threading.Timer(10, fun_restart_timer)
    timer.start()

def make_response(data=None, error=None, status_code=HTTPStatus.OK):
    ret = {}
    if data is None and error is None:
        raise('at least one of data or error')
    if data is not None:
        ret['data'] = data
    if error is not None:
        ret['error'] = error

    return flask.make_response(flask.jsonify(ret), status_code)

def to_bool(val):
    if isinstance(val, bool):
        return val
    val = val.lower()

    if val in ('y', 'yes', 't', 'True', 'TRUE','true', 'on', '1'):
        return True
    elif val in ('n', 'no', 'f', 'false', 'off', '0'):
        return False
    elif val == 1:
        return True
    elif val == 0:
        return False
    else:
        raise BooleanArgumentError("invalid boolean value %r" % (val,))

def execShell(cmd):

    print(cmd)
    err,result = subprocess.getstatusoutput(cmd)
    return err,result

def get_pretty_result(data):
    #对传进来的数据进行转化
    result = str(data) + "M"
    if data > 1000:
        data = round((data / 1024.0),2)
        result = str(data)+ "G"
    else:
        result = str(data)+"M"
    return result


class SystemIP(MethodView):
    def get(self):
        try:
            res = system_fun.getIP()
            print(res)
            return make_response(res, status_code=HTTPStatus.OK)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


    def post(self, group_id=None, second_route=False):
        response_data = {}
        Product = get_product()
        try:
            content_type = request.content_type.split(';')[0]
            status=None
            device=None
            new_ip = None
            netmask=None
            gateway=None
            dns=None
            reboot_flag=None
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                status = content.get('status', None)
                device = content.get('device', None)
                new_ip = content.get('new_ip', None)
                netmask = content.get('netmask', None)
                gateway = content.get('gateway', None)
                dns = content.get('dns', None)
                reboot_flag = content.get('isreboot', None)

            elif content_type == 'multipart/form-data':
                status = request.form.get('status', None)
                device = request.form.get('device', None)
                new_ip = request.form.get('new_ip', None)
                gateway = request.form.get('gateway', None)
                netmask = request.form.get('netmask', None)
                dns = request.form.get('dns', None)
                reboot_flag = request.form.get('isreboot', None)

            # 检验参数类型
            if status is None:
                response_data['message'] = "need the param of status"
                response_data['chinese_message'] = "缺少参数status"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(status, str):
                response_data['message'] = "the param of status must be string"
                response_data['chinese_message'] = "参数status必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if status == "":
                response_data['message'] = "the param of status can not be empty"
                response_data['chinese_message'] = "参数status不可为空"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])


            #检验参数类型
            if device is None:
                response_data['message'] = "need the param of device"
                response_data['chinese_message'] = "缺少参数device"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

            if not isinstance(device,str):
                response_data['message'] = "the param of device must be string"
                response_data['chinese_message'] = "参数device必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])


            if device == "":
                response_data['message'] = "the param of device can not be empty"
                response_data['chinese_message'] = "参数device不可为空"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            #静态地址修改时必选
            if status == "static":

                if new_ip is None:
                    response_data['message'] = "need the param of new_ip"
                    response_data['chinese_message'] = "缺少参数new_ip"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if new_ip == "":
                    response_data['message'] = "the param of new_ip can not be empty"
                    response_data['chinese_message'] = "配置静态地址，参数new_ip不可为空"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if not isinstance(new_ip, str):
                    response_data['message'] = "the param of new_ip must be string"
                    response_data['chinese_message'] = "参数new_ip必须为字符串"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
                if netmask is None:
                    response_data['message'] = "need the param of netmask"
                    response_data['chinese_message'] = "缺少参数netmask"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
                if netmask == "":
                    response_data['message'] = "the param of netmask can not be empty"
                    response_data['chinese_message'] = "配置静态地址，参数netmask不可为空"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])



                if not isinstance(netmask, str):
                    response_data['message'] = "the param of netmask must be string"
                    response_data['chinese_message'] = "参数netmask必须为字符串"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if gateway is None:
                    response_data['message'] = "need the param of gateway"
                    response_data['chinese_message'] = "缺少参数gateway"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if not isinstance(gateway, str):
                    response_data['message'] = "the param of gateway must be string"
                    response_data['chinese_message'] = "参数gateway必须为字符串"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if gateway == "":
                    response_data['message'] = "the param of gateway can not be empty"
                    response_data['chinese_message'] = "配置静态地址，参数gateway不可为空"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if dns is None:
                    response_data['message'] = "need the param of dns"
                    response_data['chinese_message'] = "缺少参数dns"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if not isinstance(dns, str):
                    response_data['message'] = "the param of dns must be string"
                    response_data['chinese_message'] = "参数dns必须为字符串"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if dns == "":
                    response_data['message'] = "the param of dns can not be empty"
                    response_data['chinese_message'] = "配置静态地址，参数dns不可为空"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

            if reboot_flag is not None:
                if not isinstance(reboot_flag, bool):
                    response_data['message'] = "the param of reboot_flag must be boolean"
                    response_data['chinese_message'] = "参数reboot_flag必须为布尔类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])


            if os.path.exists('/bm_bin/bm_set_ip'):
                script_dir = '/bm_bin/' 
            else:
                script_dir = '/sbin/'

            print(new_ip)
            if new_ip is None or new_ip == '':
                cmd_str = script_dir + 'bm_set_ip_auto %s'%(device)
            else:
                cmd_str = script_dir + 'bm_set_ip %s %s %s %s %s'%(device,new_ip,netmask,gateway,dns)

            print(cmd_str)
            result,data=execShell(cmd_str)
            if result == 0:
                if to_bool(reboot_flag) == True:
                    restart_service()
                return make_response({'ip':new_ip})
            else:
                _logger.info("===api ip, result:{},data:{}".format(result,data))
                return make_error_response(ErrorResponseType.SERVER_ERROR)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class SystemHostname(MethodView):
    def get(self):
        try:
            response_data ={}
            response_data = system_fun.getHostName()

            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

    def post(self, group_id=None, second_route=False):
        try:
            response_data = {}
            content_type = request.content_type.split(';')[0]
            new_name = None
            result = 255
            err1, old_host = execShell("hostname")

            if err1 != 0:
                _logger.info("===api hostname, result:{},old_host:{}".format(err1, old_host))
                return make_error_response(ErrorResponseType.SERVER_ERROR)

            print("old_host:" + old_host)


            if content_type == 'application/json':
                content = request.get_json(silent=True)
                new_name = content.get('hostname', None)

            elif content_type == 'multipart/form-data':
                new_name = request.form.get('hostname', None)

            # 检查输入得用户名类型和是否必选
            if new_name is None:
                response_data['message'] = "need the param of hostname"
                response_data['chinese_message'] = "缺少参数hostname"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

            if not isinstance(new_name,str):
                response_data['message'] = "the param of hostname must be string"
                response_data['chinese_message'] = "参数hostname必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])


            if '!' in new_name:
                response_data['message'] = "invaild input"
                response_data['chinese_message'] = "无效输入"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

            if new_name == old_host:
                return make_response({'hostname': new_name})

            if new_name == old_host:
                return make_response({'hostname': new_name})
            print(new_name)


            result_str = None
            if new_name != None:
                cmd_str = 'hostnamectl set-hostname %s'%(new_name)
                cmd_str1 = 'avahi-set-host-name %s'%(new_name)
                print(cmd_str)
                print(cmd_str1)
                result_str,data=execShell(cmd_str)
                hostname_path='/etc/hostname'
                print(hostname_path)
                with open(hostname_path, 'w+') as f:
                    f.write(new_name)

                err1, hostname_box_list = execShell("hostname")

                if err1 != 0:
                    _logger.info("===api hostname, result:{},hostname_box_list:{}".format(err1, hostname_box_list))
                    return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                hostname_box = hostname_box_list
                print("hostname_box_list:" + hostname_box_list)
                if '\n' in hostname_box_list[0]:
                    hostname_box = hostname_box_list[0].strip('\n')

                if hostname_box == new_name:
                    result_str = 0
                else:
                    result_str = 1
                result_str1,data=execShell(cmd_str1)

            if result_str == 0 :
                t_host="127.0.1.1 "
                hosts_path = '/etc/hosts'
                print(t_host)
                with open(hosts_path,"r",encoding="utf-8") as f:
                    lines = f.readlines()
                with open(hosts_path,"w",encoding="utf-8") as f_w:
                    find = False
                    for line in lines:
                        if t_host in line:
                            line = t_host + new_name
                            find = True
                        f_w.write(line)
                    if find == False:
                        f_w.write(t_host + new_name)
                return make_response({'hostname': new_name})
            else:
                _logger.info("===api hostname, result:{},data:{}".format(result_str1, data))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class SystemTemperature(MethodView):
    def get(self):
        response_data= {}
        try:
            board_temperature,core_temperature = system_fun.getSystemTemperature()
            return make_response({'board_temperature': str(board_temperature)+"'C","core_temperature":str(core_temperature)+"'C"})
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

class SystemTpuRate(MethodView):
    def get(self):
        try:
            tpuData = system_fun.getTpuData()
            return make_response(tpuData)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class SystemCpuRate(MethodView):
    def get(self):
        response_data={}
        Product = get_product()
        try:

            response_data = system_fun.getCpuData()
            return make_response(response_data)

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)



class SystemTime(MethodView):
    def get(self):
        response_data={}
        try:
            # msg = dict()
            str_sys_time = int(time.time()*1000)
            response_data['time'] = str_sys_time

            err1, time_zone = execShell("date -R | awk '{print $6}'")
            time_zone = int(-int(time_zone)/100)
            if err1 != 0:
                _logger.info("===api tpurate, result:{},time_zone:{}".format(err1, time_zone))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

            response_data['timezone']= time_zone
            return make_response(response_data,status_code=HTTPStatus.OK)

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

    def post(self):
        try:
            response_data ={}
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                set_time = content.get('time', None)
                timezone = content.get('timezone', None)

            elif content_type == 'multipart/form-data':
                set_time = request.form.get('time', None)
                timezone = request.form.get('timezone', None)

            else:
                return make_response(error='unsupported content_type')

            #先验证数据类型
            if set_time is None:
                response_data['message'] = "need the param of time"
                response_data['chinese_message'] = "缺少参数time"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

            if not isinstance(set_time,int):
                response_data['message'] = "the param of time must be integer"
                response_data['chinese_message'] = "参数time必须为整数"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

            if timezone is None:
                response_data['message'] = "need the param of timezone"
                response_data['chinese_message'] = "缺少参数timezone"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(timezone, int):
                response_data['message'] = "the param of timezone must be integer"
                response_data['chinese_message'] = "参数timezone必须为整数类型"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            final_set_time = time.asctime(time.localtime(int(set_time/1000)))
            date_res,data = execShell('date -s "%s"' % final_set_time)
            execShell('sudo hwclock -w')
            if date_res != 0:
                _logger.info("===api system_time, result:{},data:{}".format(date_res, data))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

            #设置时区
            if(get_product() == "SE3"):
                execShell('rm -rf /factory/root/etc/localtime')
                res, data = execShell('sudo cp /usr/share/zoneinfo/Etc/GMT%s /factory/root/etc/localtime' % timezone)
            else:
                res, data = execShell('sudo cp /usr/share/zoneinfo/Etc/GMT%s /etc/localtime' % timezone)
            
            if res != 0:
                _logger.info("===api system_time_timezone, result:{},data:{}".format(res, data))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)


            response_data['time']=set_time
            response_data['timezone']=timezone

            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SystemUptime(MethodView):
    def get(self):
        response_data={}
        try:
            response_data = system_fun.getUptime()
            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class SystemBasicInfo(MethodView):
    def get(self):
        try:
            script_path = os.path.realpath(__file__)
            script_dir = os.path.dirname(script_path)
            cmd_str= script_dir + '/get_basic.sh'

            err1, basicinfo = execShell(cmd_str)

            if err1 != 0:
                _logger.info("===api basicinfo, result:{},data:{}".format(err1, basicinfo))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

            return make_response(basicinfo)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SystemRegularReboot(MethodView):
    def get(self):
        response_data={}
        try:
            croninfo = []
            with open("/etc/crontab") as f:
                lines = f.readlines()
                for line in lines:
                    if "CUSTOMER CMD reboot FOR BITMAIN" in line:
                        croninfo = line.split(  )
                print(croninfo)
                result = dict()
                if len(croninfo) > 5 :
                    result['hour'] = croninfo[1]
                    result['days'] = croninfo[4]
                else:
                    result['hour'] = ""
                    result['days'] = ""


                return make_response(result)

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


    def post(self, group_id=None, second_route=False):
        response_data={}
        Product = get_product()
        try:
            content_type = request.content_type.split(';')[0]
            days = None
            hour=None
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                hour = content.get('hour', None)
                days = content.get('days', None)

            elif content_type == 'multipart/form-data':
                hour = request.form.get('hour', None)
                days = request.form.get('days', None)

            #验证参数类型
            if days is None:
                response_data['message'] = "need the param of days"
                response_data['chinese_message'] = "缺少参数days"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(days, str):
                response_data['message'] = "the param of days must be string"
                response_data['chinese_message'] = "参数days必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if hour is None:
                response_data['message'] = "need the param of hour"
                response_data['chinese_message'] = "缺少参数hour"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(hour, str):
                response_data['message'] = "the param of hour must be string"
                response_data['chinese_message'] = "参数hour必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            #判断给定参数是否符合要求
            days_list = days.split(",")
            hours_list = hour.split(",")

            for per_day in days_list:
                if per_day not in ["","1","2","3","4","5","6","7"]:
                    response_data['message'] = "the param of days value error"
                    response_data['chinese_message'] = "参数days值错误，不在规定范围内"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
            for per_hour in hours_list:
                if per_hour not in ["","00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17",
                                    "18","19","20","21","22","23"]:
                    response_data['message'] = "the param of hour value error"
                    response_data['chinese_message'] = "参数hour值错误,不在规定范围内"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])


            script_path = os.path.realpath(__file__)
            script_dir = os.path.dirname(script_path)

            if Product == "SE3":
                clear_shell='/clear_regular_reboot_SE3.sh'
                set_shell='/set_regular_reboot_SE3.sh %s %s'
            else:
                clear_shell='/clear_regular_reboot.sh'
                set_shell='/set_regular_reboot.sh %s %s'
            print(days)
            if days is None or days == '':
                cmd_str = script_dir + clear_shell
            else:
                cmd_str = script_dir + set_shell%(hour,days)

            print(cmd_str)
            result,data=execShell(cmd_str)
            if result == 0:
                return make_response({'days':days,"hour":hour})
            else:
                _logger.info("===api regularreboot, result:{},data:{}".format(result, data))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class CopyDataToSD(MethodView):
    def post(self):
        try:
            inside_api = 'http://localhost:5555/SophonUtil/api/download'  # 生成压缩包的api接口
            identity_ids = request.form.getlist('identity_ids',None)
            post_identity_ids = []
            print(identity_ids,'identity')
            for identity_id in identity_ids:
                post_identity_ids.append(('identity_ids',identity_id))
            resp = requests.request('POST',
                                    inside_api,
                                    data=post_identity_ids,
                                    timeout=1000 * 60 * 10,
                                    verify=False)

            if not os.path.exists('/data/config/download/export.zip'):
                error = dict()
                error['message'] = 'Data product failed,please check inside api'
                error['status'] = 'Export api does not product a *.zip'
                error['code'] = 40502
                return make_response(error=error, status_code=HTTPStatus.BAD_REQUEST)
            else:
                data_folder = '/data/config/download/export.zip'
                data_size = os.path.getsize(data_folder)
                err1, sd_str = execShell("fdisk -l /dev/mmcblk1 | grep /dev/mmcblk1p | awk '{print $1}'")

                print("query result: " + sd_str)
                if err1 != 0:
                    error = dict()
                    error['message'] = 'SD card list get failed'
                    error['code'] = 40503
                    return make_response(error=error,
                            status_code=HTTPStatus.BAD_REQUEST)
                sd_list = sd_str.split( )
                flag = 0
                error_info= ''
                if len(sd_list) > 0:
                    for i in range(len(sd_list)-1, -1, -1):
                        err1, data = execShell('mount ' + sd_list[i].strip('\n') + ' /mnt')
                        if err1 != 0 :
                            sd_size_info = os.statvfs(sd_list[i].strip('\n'))
                            sd_avail_size = sd_size_info.f_bavail * sd_size_info.f_frsize
                            print(sd_avail_size)
                            print(data_size)
                            if sd_avail_size > data_size:
                                shutil.copyfile('/data/config/download/export.zip', '/mnt/export.zip')
                                execShell('umount ' + sd_list[i].strip('\n'))
                                flag = 1
                                error_info = ''
                                break
                        else:
                            error_info = 'SD card mount failed,please check sd card type and can use'
                    if flag == 1:
                        res = dict()
                        res['save_path'] = 'The data has been saved in sd card root directory'
                        return make_response(res, status_code=HTTPStatus.OK)
                    else:
                        error = dict()
                        if error_info:
                            error['message'] = error_info
                            error['code'] = 40500
                        else:
                            error['message'] = 'SD card does not have enough space'
                            error['code'] = 40501

                        error['status'] = 'SD card has something wrong'
                        return make_response(error=error, status_code=HTTPStatus.BAD_REQUEST)
                else:
                    error = dict()
                    error['message'] = 'No SD card been detected'
                    error['code'] = 40504
                    error['status'] = 'SD card has something wrong'
                    return make_response(error=error, status_code=HTTPStatus.BAD_REQUEST)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SystemVersion(MethodView):
    def get(self):
        response_data={}
        try:
            response_data = system_fun.getSystemVersion()
            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class DetailSWVersion(MethodView):
    def get(self):
        try:
            err1, data = execShell("bm_version")
            if err1 == 0:
                return make_response({'SW info': data})
            else:
                _logger.info("===api detail_swversion, result:{},data:{}".format(err1, data))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class DeviceType(MethodView):
    def get(self):
        try:
            with open(device_type_info) as f:
                line = f.readlines()
                print(line)
                version = line[len(line)-1].split('..')[1].strip('\n').strip()
                if version == '0x00000002ffffffff':
                    version = 'bm1682-8G'
                else:
                    version = 'bm1682-4G'
                print(version)
                return make_response({'DeviceType': version})
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class DeviceSN(MethodView):
    def get(self):
        try:
            sn = system_fun.getDeviceSN()
            return make_response({'device_sn': sn})
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SwitchOtaType(MethodView):
    def get(self):
        try:
            cf=NonVolatileConfigParser()
            cf.read(ota_config_path)
            ota_type = cf['BASE']['ota_type']
            return make_response({'otaType': ota_type})
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

    def post(self, group_id=None, second_route=False):
        response_data={}
        try:
            content_type = request.content_type.split(';')[0]
            ota_type = None
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                ota_type = content.get('otaType', None)

            elif content_type == 'multipart/form-data':
                ota_type = request.form.get('otaType', None)

            print(ota_type)
            if ota_type != 'public' and ota_type != 'private':
                response_data['message'] = "the param of otaType error"
                response_data['chinese_message'] = "参数otaType错误"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

            try:
                cf=NonVolatileConfigParser()
                cf.read(ota_config_path)

                cf['BASE']['ota_type'] = ota_type
                with open(ota_config_path, 'w') as f:
                    cf.write(f)
                if ota_type == 'public':
                    execShell("sudo systemctl stop clock")
                else:
                    execShell("sudo systemctl start clock")

                return make_response({'otaType': ota_type})
            except Exception as e:
                _logger.exception(e)
                return make_error_response(ErrorResponseType.SERVER_ERROR)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class PublicOtaVersion(MethodView):
    def get(self):
        try:
            cf=NonVolatileConfigParser()
            cf.read(ota_config_path)
            public_url = cf['public_ota']['url']
            with open(device_type_info) as f:
                line = f.readlines()
                print(line)
                version = line[len(line)-1].split('..')[1].strip('\n').strip()
                if version == '0x00000002ffffffff':
                    version = 'bm1682-8G'
                else:
                    version = 'bm1682-4G'
            r = requests.get(public_url+'/'+version, verify=False,timeout=1000*60)
            if r.status_code != 200:
                error = dict()
                error['message'] = 'No version available .'
                error['code'] = 40401
                error['status'] = 'no version'
                return make_response(r.json(),status_code=404)
            return make_response(r.json())
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class SystemMonitor(MethodView):
    def get(self):
        try:
            err1, memory = execShell("free -m | grep Mem | awk '{printf $2\";\"$7}'")
            err2, data_disk_size = execShell("df -m | grep /dev/mmcblk0p7 | awk '{printf $2\";\"$4}'")
            if err1 != 0 or err2 != 0:
                _logger.info("===api system_monitor_memory, result:{},data:{}".format(err1, memory))
                _logger.info("===api system_monitor_data_disk_size, result:{},data:{}".format(err2, data_disk_size))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
            total_memory = memory.split(";")[0]
            free_memory = memory.split(";")[1]
            total_data_disk_size = data_disk_size.split(";")[0]
            free_data_disk_size = data_disk_size.split(";")[1]
            total_memory_std = round(float(total_memory) / 1024.0,2)
            free_memory_std = round(float(free_memory) / 1024.0,2)
            total_data_disk_size_std = round(float(total_data_disk_size) / 1024.0,2)
            free_data_disk_size_std = round(float(free_data_disk_size) / 1024.0,2)
            monitorInfo = dict()
            monitorInfo['total_memory'] = total_memory_std
            monitorInfo['free_memory'] = free_memory_std
            monitorInfo['total_data_disk_size'] = total_data_disk_size_std
            monitorInfo['free_data_disk_size'] = free_data_disk_size_std
            return make_response(monitorInfo)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class  SystemMemory(MethodView):

    def get(self):
        response_data={}
        try:
            response_data = system_fun.getSystemMemory()
            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class SystemDisk(MethodView):
    def get(self):
        response_data = {}
        try:

            response_data = system_fun.getSystemDisk()
            return make_response(response_data)

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class PrivateOtaUrl(MethodView):
    def get(self):
        try:
            cf=NonVolatileConfigParser()
            cf.read(ota_config_path)
            url = cf['private_ota']['url']
            return make_response({'url': url})
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

    def post(self, group_id=None, second_route=False):
        try:
            content_type = request.content_type.split(';')[0]
            new_url = None
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                new_url = content.get('url', None)

            elif content_type == 'multipart/form-data':
                new_url = request.form.get('url', None)

            print(new_url)
            if new_url == None:
                error = dict()
                error['message'] = 'input wrong data'
                error['code'] = 40011
                error['status'] = 'input wrong data'
                return make_response(error=error, status_code=HTTPStatus.BAD_REQUEST)

            try:
                cf=NonVolatileConfigParser()
                cf.read(ota_config_path)

                with open(device_type_info) as f:
                    line = f.readlines()
                    version = line[len(line)-1].split('..')[1].strip('\n').strip()
                    if version == '0x00000002ffffffff':
                        version = 'bm1682-8G'
                    else:
                        version = 'bm1682-4G'
                new_url = new_url + '/' + version
                cf['private_ota']['url'] = new_url
                with open(ota_config_path, 'w') as f:
                    cf.write(f)
                return make_response({'url': new_url})
            except FileNotFoundError:
                error = dict()
                error['message'] = 'new_url write failed.'
                error['code'] = 40011
                error['status'] = 'new_url write failed.'
                return make_response(error=error, status_code=HTTPStatus.BAD_REQUEST)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class OtaUpdated(MethodView):
    def post(self, group_id=None, second_route=False):
        try:
            content_type = request.content_type.split(';')[0]
            new_url = None
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                update_url = content.get('updateUrl', None)

            elif content_type == 'multipart/form-data':
                update_url = request.form.get('updateUrl', None)

            print(update_url)
            if update_url == None:
                error = dict()
                error['message'] = 'input wrong data'
                error['code'] = 40011
                error['status'] = 'input wrong data'
                return make_response(error=error, status_code=HTTPStatus.BAD_REQUEST)

            err1, run_status = execShell("ps -ef|grep cloud_ota.py|grep -v grep| awk '{print $9}'")

            if err1 != 0:
                error = dict()
                error['msg'] = 'run_status get failed'
                error['code'] = 40011
                return make_response(error=error,
                        status_code=HTTPStatus.BAD_REQUEST)

            if len(run_status) > 0:
                return make_response({'status': 'Download already running,please not repeat download'})

            try:
                cmd_str = 'python3 /data/ota/cloud_ota.py --url %s'%(update_url)
                print(cmd_str)

                # result_fd = os.popen(cmd_str)
                # result = result_fd.readlines()[-1].strip()
                # result_fd.close()

                err1, result = execShell(cmd_str)

                if err1 != 0:
                   error = dict()
                   error['msg'] = 'result get failed'
                   error['code'] = 40011
                   return make_response(error=error,
                           status_code=HTTPStatus.BAD_REQUEST)

                print("result:"+result)
                status, path_sh, version_now, path_md5, path_file = result.split(' ', 4)
                print(path_file)
                if status == '500':
                    error = dict()
                    error['message'] = 'Please check network status,download failed..'
                    error['status'] = 'Network connect failed...'
                    error['code'] = 40011
                    return make_response(error=error, status_code=HTTPStatus.BAD_REQUEST)
                elif status == '200':
                    execShell(path_sh + ' ' + version_now + ' ' + path_md5 + ' ' + path_sh + ' ' + path_file + ' ' + '&')
                    res = dict()
                    res['message'] = 'Download succeeded,updating....'
                    res['updateUrl'] = update_url
                    res['status'] = 'Updating'
                    return make_response(res, status_code=HTTPStatus.OK)
            except FileNotFoundError:
                error = dict()
                error['message'] = 'ota update failed.'
                error['code'] = 40011
                error['status'] = 'ota update failed.'
                return make_response(error=error, status_code=HTTPStatus.BAD_REQUEST)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class LocalUpdate(MethodView):
    def post(self, version_now=None):
        Product = get_product()
        try:
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                version_now = content.get('version', None)

            elif content_type == 'multipart/form-data':
                version_now = request.form.get('version', None)

            if version_now == None:
                response_data = {}
                response_data['message'] = "need the param of version"
                response_data['chinese_message'] = "缺少参数version"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if Product == "SE3":
                savepath = '/factory/public_ota/'
            else:
                savepath = '/recovery/factory/public_ota/'
            local_update = 'local_update.sh'
            md5_name = 'install_md5sum.txt'
            if os.path.exists(savepath + local_update):
                execShell('chmod 777 ' + savepath + local_update)
                packages = os.listdir(savepath)
                path_file = ''
                for i in range(0, len(packages)):
                    if packages[i] != local_update and packages[i] != md5_name:
                        path_file = path_file + ' ' + savepath + packages[i]
                path_sh = savepath + local_update
                path_md5 = savepath + md5_name
                print(path_sh + ' ' + version_now + ' ' + path_md5 + ' ' + path_sh + ' ' + path_file)
                try:
                    res = dict()
                    res['message'] = 'Updateing...'
                    execShell(path_sh + ' ' + version_now + ' ' + path_md5 + ' ' + path_sh + ' ' + path_file + ' ' + '&')
                    return make_response(data=res, status_code=HTTPStatus.OK)
                except:

                    return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
            else:

                return make_error_response(ErrorResponseType.NOT_FOUND_FILE)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class PublicOtaUrl(MethodView):
    def post(self, new_url=None):
        try:
            content_type = request.content_type.split(';')[0]
            new_url = None
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                new_url = content.get('url', None)
            elif content_type == 'multipart/form-data':
                new_url = request.form.get('url', None)
            print(new_url)
            if new_url == None:
                error = dict()
                error['message'] = 'input wrong data'
                error['code'] = 40011
                error['status'] = 'input wrong data'
                return make_response(error=error, status_code=HTTPStatus.BAD_REQUEST)

            try:
                cf = NonVolatileConfigParser()
                cf.read(ota_config_path)

                cf['public_ota']['url'] = new_url
                with open(ota_config_path, 'w') as f:
                    cf.write(f)
                return make_response({'url': new_url})
            except FileNotFoundError:
                error = dict()
                error['message'] = 'new_url write failed.'
                error['code'] = 40011
                error['status'] = 'new_url write failed.'
                return make_response(error=error, status_code=HTTPStatus.BAD_REQUEST)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SystemTimeMode(MethodView):

    def get(self):
        response_data = {}
        try:

            err1, query_str = execShell("ps -ef|grep systemd-timesyncd|grep -v grep")
            if err1 == 0:
                response_data['time_select_mode'] = "0"
            else:
                response_data['time_select_mode'] = "1"
            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


    def post(self):
        response_data={}
        Product = get_product()
        try:
            time_select_mode=None
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                time_select_mode = content.get('time_select_mode', None)
                # set_time = content.get('time', None)
                # timezone = content.get('timezone', None)

            elif content_type == 'multipart/form-data':
                time_select_mode = request.form.get('time_select_mode', None)
                # set_time = request.form.get('time', None)
                # timezone = request.form.get('timezone', None)

            else:
                return make_response(error='unsupported content_type')

            #先验证输入的数据类型
            if time_select_mode is None:
                response_data['message'] = "need the param of time_select_mode"
                response_data['chinese_message'] = "缺少参数time_select_mode"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(time_select_mode, str):
                response_data['message'] = "the param of time_select_mode must be string"
                response_data['chinese_message'] = "参数time_select_mode必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if time_select_mode not in ["0","1"]:
                response_data['message'] = "the param of time_select_mode value is error"
                response_data['chinese_message'] = "参数time_select_mode值错误"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])



            script_path = os.path.realpath(__file__)
            script_dir = os.path.dirname(script_path)

            # set_time = time.asctime( time.localtime(int(set_time)) )

            if Product == "SE3":
                stop_ntp_sh = '/stop_ntp_SE3.sh'
                start_ntp_sh = '/start_ntp_SE3.sh'
                # res, date = execShell('sudo rm -rf /factory/root/etc/localtime')
                # res, date = execShell('sudo cp /usr/share/zoneinfo/Etc/GMT%s /factory/root/etc/localtime' % timezone)
            else:
                stop_ntp_sh = '/stop_ntp.sh'
                start_ntp_sh = '/start_ntp.sh'
                # res, date = execShell('sudo cp /usr/share/zoneinfo/Etc/GMT%s /etc/localtime' % timezone)
            # if res != 0:
            #     print(res)
            #     return make_response(error='timezone set was wrong')
            cmd_dir=""
            if time_select_mode == "1":
                cmd_dir = script_dir + stop_ntp_sh
            else:
                cmd_dir=script_dir + start_ntp_sh

            result,data = execShell('bash %s' % cmd_dir)
            if result != 0:
                _logger.info("===api system_time_mode, result:{},data:{}".format(result, data))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)


            response_data['time_select_mode'] = time_select_mode
            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class NtpConfig(MethodView):
    def get(self):
        response_data={}
        try:
            with open(config_ntp) as f:
                lines = f.readlines()
                for line in lines:
                    if 'NTP=' in line:
                        ntp_config = line.split('NTP=')[1].strip('\n').strip()

            err1, time_zone = execShell("date -R | awk '{print $6}'")
            time_zone = int(-int(time_zone) / 100)
            if err1 != 0:
                _logger.info("===api ntp_config_timezone, result:{},time_zone:{}".format(err1, time_zone))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

            now_time = int(time.time()*1000)
            return make_response({'ntp_config': ntp_config,"timezone":time_zone,"time":now_time})

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

    def post(self):
        response_data={}
        try:
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                ntp_config = content.get('ntp_config', None)
                timezone = content.get('timezone', None)

            elif content_type == 'multipart/form-data':
                ntp_config = request.form.get('ntp_config', None)
                timezone = request.form.get('timezone', None)

            #检验传入的参数
            if ntp_config is None:
                response_data['message'] = "need the param of ntp_config"
                response_data['chinese_message'] = "缺少参数ntp_config"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

            if not isinstance(ntp_config,str):
                response_data['message'] = "the param of ntp_config must be string"
                response_data['chinese_message'] = "参数ntp_config必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

            if timezone is None:
                response_data['message'] = "need the param of timezone"
                response_data['chinese_message'] = "缺少参数timezone"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(timezone, int):
                response_data['message'] = "the param of timezone must be integer"
                response_data['chinese_message'] = "参数timezone必须为整数类型"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])




            res, data = execShell('sudo cp /usr/share/zoneinfo/Etc/GMT%s /etc/localtime' % timezone)
            if res != 0:
                return make_response(error='timezone set was wrong')
            file_data = ""

            with open(config_ntp) as f:
                lines = f.readlines()

            with open(config_ntp,"w") as fw:
                for line in lines:
                    if 'NTP=' in line:
                        line = "NTP=" + ntp_config + "\n"
                    file_data += line

                fw.write(file_data)
            script_path = os.path.realpath(__file__)
            script_dir = os.path.dirname(script_path)
            cmd_dir = script_dir + '/start_ntp.sh'
            execShell('bash %s' % cmd_dir)
            now_time = int(time.time()*1000)
            return make_response({'ntp_config': ntp_config,"timezone":timezone,"time":now_time})

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)



# 本地升级文件上传
class LocalUpdateUploadFile(MethodView):
    def __init__(self):
        Product = get_product()
        try:
            if Product == "SE3":
                self.upload_path = '/factory/public_ota/'
            else:
                self.upload_path = '/recovery/factory/public_ota/'

            self.LocalUpdate_URL = 'http://localhost:8888/SophonSystem/api/localUpdate'
        except Exception as e:
            _logger.exception(e)


    def post(self):
        try:
            md5 = request.form.get('md5',None)
            upload_file = request.files.get('file',None)
            print('---start checking----')
            if not md5 or md5 is None:
                return make_error_response(ErrorResponseType.MISS_MD5_INFORMATION)
            if not upload_file or upload_file is None:
                return make_error_response(ErrorResponseType.NO_FILE_UPLOADED)
            subfix_re = re.compile('.+\.(zip|tar|tgz)')
            if subfix_re.match(upload_file.filename) is None:

                return make_error_response(ErrorResponseType.UPLOAD_FILE_NOT_VALID)
            # check md5
            print("----------start check md5------------.")
            hasher = hashlib.md5()
            while True:
                block = upload_file.read(4096)
                if not block:
                    break
                hasher.update(block)
            md5_sum = hasher.hexdigest()
            if md5_sum == md5:
                print("----------check md5 success-------")
                upload_file.seek(0)
                upload_path = self.upload_path
                print("------delete file under /factory/public_ota/-------")
                execShell('rm -rf '+upload_path+'*')
                print("-------unpack file-----------")
                try:
                    if '.tar' in upload_file.filename or '.tgz' in upload_file.filename:
                        tar = tarfile.open(fileobj=upload_file)
                        tar.extractall(upload_path)
                        tar.close()
                    if '.zip' in upload_file.filename:
                        zip_file = zipfile.ZipFile(upload_file)
                        zip_file.extractall(upload_path)
                        zip_file.close()
                    print("------unpack file done-------")
                    version = os.path.splitext(upload_file.filename)[0]
                    upload_file.close()
                    print("-------request api-----------")
                    r = requests.post(self.LocalUpdate_URL,json={"version":version},timeout=1000*60,verify=False)
                    print("-------request finish--------")
                    if r.status_code == 400:
                        error_response = r.json()
                        error_type = error_response['error']['code']
                        # 将sdk的报错替换为fog的报错类型
                        error_code_str = str(error_type)
                        error_status_code = error_code_str[0:3]

                        error_name = error_response['error']['status']
                        message = error_response['error']['message']
                        chinese_message = ""
                        if error_response['error'].get('chinese_message', ''):
                            chinese_message = error_response['error']['chinese_message']

                        return make_response(
                            error={
                                'code': error_type,
                                'status': error_name,
                                'message': message,
                                "chinese_message": chinese_message
                            },
                            status_code=error_status_code)

                    elif r.status_code == 200:
                        return jsonify({'status':'success'})
                    else:

                        return make_error_response(ErrorResponseType.CALL_UPDATE_FUNCTION_NO_REPEAT)
                except tarfile.ReadError:

                    upload_file.close()
                    return make_error_response(ErrorResponseType.FILE_IS_BROKEN)
                except zipfile.BadZipFile:

                    upload_file.close()
                    return make_error_response(ErrorResponseType.FILE_IS_BROKEN)
                except ConnectionError:

                    upload_file.close()
                    return make_error_response(ErrorResponseType.CALL_UPDATE_FUNCTION_NO_REPEAT)
                except OSError:

                    upload_file.close()
                    return make_error_response(ErrorResponseType.SAVE_FILE_ERROR)
            else:

                upload_file.close()
                return make_error_response(ErrorResponseType.CHECK_MD5_ERROR)

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class SystemFan(MethodView):
    def get(self):
        response_data={}
        Product = get_product()
        try:
            fan_rate = system_fun.getSystemFan()
            return make_response({"fan_speed": str(fan_rate)+"r/min"})

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)



#系统日志下载
class SystemLogs(MethodView):

    def get(self):
        try:
            response_data={}
            try:

                get_logs_type = request.args.get('get_logs_type', default=None, type=str)

            except Exception as e:
                response_data['message'] = "get the params failed"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'])

            #检验传入参数得有效性
            if get_logs_type is None:
                response_data['message'] = "need the param of get_logs_type"
                response_data['chinese_message'] = "缺少参数get_logs_type"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(get_logs_type, str):
                response_data['message'] = "the param of get_logs_type must be string"
                response_data['chinese_message'] = "参数get_logs_type必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if get_logs_type not in ["0","1"]:
                response_data['message'] = "the param of get_logs_type value is error"
                response_data['chinese_message'] = "参数get_logs_type值错误"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])



            download_folder_path = '/data'
            hole_pack_name=""
            if get_logs_type == "0":
                #压缩日志
                hole_pack_name = 'system.tgz'
                cmd_str = 'tar -zcf /data/' + hole_pack_name + ' /var/log/* --warning=no-file-changed'
            else:
                #压缩日志
                hole_pack_name ="application.tgz"
                cmd_str = 'tar -zcf /data/' + hole_pack_name + ' /data/log/* --warning=no-file-changed'


            err, result = subprocess.getstatusoutput(cmd_str)
            if err !=0 and err !=1:
                _logger.info("===api system_logs, result:{},data:{}".format(err, result))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
            # 导出压缩包
            return send_from_directory(download_folder_path, hole_pack_name, as_attachment=True,)

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SystemHardwareInfo(MethodView):
    def get(self):
        try:
            model,product_version,device_sn,chip_sn = system_fun.getSystemHardwareInfo()
            return make_response({'model': model, 'product_version': product_version, 'device_sn': device_sn,
                                      'chip_sn': chip_sn})
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

#获取系统模式
class SystemMode(MethodView):

    def get(self):
        response_data={}
        line = ""
        try:
            with open("/data/config/system_mode", mode="r") as f:
                line = f.read()
                line = line.strip('\n')

            print("current system mode: {}".format(line))

            if line == "gate":
                re_str = '1'
            else:
                re_str = '0'
            return make_response({'systemMode': re_str})
        except Exception as e:
            #_logger.exception(e)
            return make_response({'systemMode': "0"})

class SystemRtmp(MethodView):
    #开启码流转化
    def post(self, group_id=None, second_route=False):
        response_data = {}

        try:
            video_id=None
            rtsp_address=None
            rtmp_address=None
            is_start_rtmp=None
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                video_id = content.get('video_id', None)
                rtsp_address = content.get('rtsp_address', None)
                rtmp_address = content.get('rtmp_address', None)
                is_start_rtmp = content.get('is_start_rtmp', None)

            elif content_type == 'multipart/form-data':
                video_id = request.form.get('video_id', None)
                rtsp_address = request.form.get('rtsp_address', None)
                rtmp_address = request.form.get('rtmp_address', None)
                is_start_rtmp = request.form.get('is_start_rtmp', None)


            if video_id is None:
                response_data['message'] = "need the param of video_id"
                response_data['chinese_message'] = "缺少参数video_id"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(video_id, str):
                response_data['message'] = "the param of video_id must be string"
                response_data['chinese_message'] = "参数video_id必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if rtsp_address is None:
                response_data['message'] = "need the param of rtsp_address"
                response_data['chinese_message'] = "缺少参数rtsp_address"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(rtsp_address, str):
                response_data['message'] = "the param of rtsp_address must be string"
                response_data['chinese_message'] = "参数rtsp_address必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if rtmp_address is None:
                response_data['message'] = "need the param of rtmp_address"
                response_data['chinese_message'] = "缺少参数rtmp_address"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(rtmp_address, str):
                response_data['message'] = "the param of rtmp_address must be string"
                response_data['chinese_message'] = "参数rtmp_address必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if is_start_rtmp is None:
                response_data['message'] = "need the param of is_start_rtmp"
                response_data['chinese_message'] = "缺少参数is_start_rtmp"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(is_start_rtmp, bool):
                response_data['message'] = "the param of is_start_rtmp must be boolean"
                response_data['chinese_message'] = "参数is_start_rtmp必须为布尔类型"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])
            mode_sign = ""
            if is_start_rtmp == True:
                mode_sign = "start"
            else:
                mode_sign= "stop"

            _logger.info("the sign of rtmp service:{}".format(mode_sign))
            cmd_str = '/bm_bin/bm_rtmp %s "%s" %s %s' % (video_id, rtsp_address, rtmp_address, mode_sign)
            result, data = execShell(cmd_str)
            if result!= 0:
                _logger.info("===api rtmp, result:{},data:{}".format(result, data))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

            response_data['success'] = True

            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

def sendMsgToLte(cmd):
    print("sendMsgToLte!!!" + cmd)
    clinet = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    clinet.connect(("localhost", 9191))
    data = cmd
    clinet.send(data.strip().encode("utf-8"))
    serv_data = clinet.recv(1024)
    res = serv_data.decode("utf-8")
    print(res)
    clinet.close()
    if (res == '0' and len(res) == 1):
        return 0, ''
    elif (res == 'error'):
        return 127, 'exec failed'
    else:
        return 0, res

#LTE模块
class SystemLteModem(MethodView):
    def get(self):
        try:
            err, result = execShell('lsusb | grep 1508:1001')
            if len(result) < 10:
                _logger.info("not found 4G module")
                return make_response({'state' : False,'service': 'inactive'})

            err, result = execShell('systemctl is-active lteModemManager.service')
            if 'active' == result:
                re_str = 'active'
            else:
                re_str = 'inactive'
            return make_response({'state' : True,'service': re_str})

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

    def post(self, group_id=None, second_route=False):
        Product = get_product()
        response_data = {}
        try:
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                service = content.get('service', None)

            elif content_type == 'multipart/form-data':
                service = request.form.get('service', None)

            err, result = execShell('lsusb | grep 1508:1001')
            if len(result) < 10:
                _logger.info("not found 4G module")
                return make_error_response(ErrorResponseType.NOT_FOUND_4G_MODULE)

            if Product == "SE3":
                return make_response({'service': 'SE3 not support'})
            else:
                if service == 'active':
                    err1, result1 = execShell('systemctl enable lteModemManager.service')
                    err2, result2 = execShell('systemctl start lteModemManager.service')
                elif service == 'inactive':
                    err1, result1 = execShell('systemctl stop lteModemManager.service')
                    err2, result2 = execShell('systemctl disable lteModemManager.service')
                else:
                    response_data['message'] = "param input error"
                    response_data['chinese_message'] = "参数service只支持输入active or inactive"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                            chinese_message=response_data['chinese_message'])

            if err1 == 0 and err2 == 0:
                return make_response({'service': service})
            else:
                _logger.info("==== api ltemode error")
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SystemLteModemConnect(MethodView):
    def get(self):
        try:
            err, result = execShell('systemctl is-active lteModemManager.service')
            if  result != 'active':
                return make_response({'connected': False,'simstatus':False})

            err, result = execShell('ping -I ppp0 www.baidu.com -c 4 -i 0.5 -W 1')

            if '4 packets transmitted, 4 received,' in result:
                return make_response({'connected': True, 'simstatus':True})
            else:
                print(result)
                err, result = execShell('systemctl is-active lteModemManager.service')
                if  result != 'active':
                    return make_response({'connected': False,'simstatus':False})
                    
                err, simstatus = sendMsgToLte('get simstatus')
                status=False
                if 'SIM CARD OK' in simstatus:
                    status=True
                return make_response({'connected': False,'simstatus':status})
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SystemLteModemSimStatus(MethodView):
    def get(self):
        try:
            err, result = execShell('systemctl is-active lteModemManager.service')
            if  result != 'active':
                _logger.info("lte Modem not open")
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

            err, simstatus = sendMsgToLte('get simstatus')
            status=False
            if 'SIM CARD OK' in simstatus:
                status=True
            return make_response({'simstatus': status, 'description': simstatus})
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)            

class SystemLteModemSelection(MethodView):
    def get(self):
        try:
            err, result = execShell('systemctl is-active lteModemManager.service')
            if  result != 'active':
                _logger.info("lte Modem not open")
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

            err, ltefirst = sendMsgToLte('get ltefirst')
            if ltefirst == 'True':
                re_str = 'ltefirst'
            elif ltefirst == 'False':
                re_str = 'wanfirst'
            else:
                _logger.info('ltefirst value is {}'.format(ltefirst))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

            return make_response({'selection': re_str})
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

    def post(self, group_id=None, second_route=False):
        Product = get_product()
        try:
            content_type = request.content_type.split(';')[0]
            days = None
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                selection = content.get('selection', None)

            elif content_type == 'multipart/form-data':
                selection = request.form.get('selection', None)

            err, result = execShell('systemctl is-active lteModemManager.service')
            if  result != 'active':
                _logger.info("lte Modem not open")
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

            if Product == "SE3":
                return make_response({'status': 'SE3 not support'})
            else:
                if selection == 'ltefirst':
                    err, res = sendMsgToLte('set ltefirst True')
                else:
                    err, res = sendMsgToLte('set ltefirst False')

            if err == 0:
                return make_response({'selection': selection})
            else:
                _logger.info("==== api SystemLteModemSelection,result:{},data:{}".format(err,res))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class SystemAlarm(MethodView):

    def __init__(self):
        self.configdata = ConfigDataSingletone()

    def get(self):
        response_data = {}
        try:

            alarm_address_string = self.configdata.getItemConfig('ALARM_ADDRESS_LIST')
            detect_period=self.configdata.getItemConfig('DETECT_PERIOD')
            alarm_period=self.configdata.getItemConfig('ALARM_PERIOD')
            fan_speed_min=self.configdata.getItemConfig('FAN_SPEED_MIN')
            fan_speed_max=self.configdata.getItemConfig('FAN_SPEED_MAX')
            board_temperature=self.configdata.getItemConfig('BOARD_TEMPERATURE')
            temperature=self.configdata.getItemConfig('TEMPERATURE')
            cpu_rate=self.configdata.getItemConfig('CPU_RATE')
            tpu_rate=self.configdata.getItemConfig('TPU_RATE')

            disk_rate=self.configdata.getItemConfig('DISK_RATE')
            external_hard_disk_rate=self.configdata.getItemConfig('EXTERNAL_HARD_DISK_RATE')

            response_data['alarm_address_list'] = alarm_address_string.split(",")
            if "" in response_data['alarm_address_list']:
                response_data['alarm_address_list'].remove("")
            response_data['detect_period'] =detect_period
            response_data['alarm_period'] =alarm_period
            response_data['fan_speed_min'] =fan_speed_min
            response_data['fan_speed_max'] =fan_speed_max
            response_data['board_temperature'] = board_temperature
            response_data['temperature'] = temperature
            response_data['cpu_rate'] =cpu_rate
            response_data['tpu_rate'] =tpu_rate

            response_data['disk_rate'] =disk_rate
            response_data['external_hard_disk_rate'] =external_hard_disk_rate



        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

        return make_response(response_data)

    def post(self, second_route=False):
        try:
            response_data ={}
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                alarm_address_list = content.get('alarm_address_list', None)
                detect_period = content.get('detect_period', None)
                alarm_period = content.get('alarm_period', None)

                fan_speed_min = content.get('fan_speed_min', None)
                fan_speed_max = content.get('fan_speed_max', None)
                board_temperature = content.get('board_temperature', None)
                temperature = content.get('temperature', None)
                cpu_rate = content.get('cpu_rate', None)
                tpu_rate = content.get('tpu_rate', None)
                disk_rate = content.get("disk_rate", None)
                external_hard_disk_rate = content.get("external_hard_disk_rate", None)

            elif content_type == 'multipart/form-data':
                alarm_address_list = request.form.get('alarm_address_list', None)
                detect_period = request.form.get('detect_period', None)
                alarm_period = request.form.get('alarm_period', None)
                fan_speed_min = request.form.get('fan_speed_min', None)
                fan_speed_max = request.form.get('fan_speed_max', None)
                board_temperature = request.form.gaet('board_temperature', None)
                temperature = request.form.get('temperature', None)
                cpu_rate = request.form.get('cpu_rate', None)
                tpu_rate = request.form.get('tpu_rate', None)

                disk_rate = request.form.get("disk_rate", None)
                external_hard_disk_rate = request.form.get("external_hard_disk_rate", None)
            else:
                return make_response(error='unsupported content_type')

            if alarm_address_list is not None:
                if not isinstance(alarm_address_list, list):
                    response_data['message'] = "the param of alarm_address_list must be list"
                    response_data['chinese_message'] = "参数alarm_address_list必须为数组(列表)类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
            if detect_period is not None:
                if not isinstance(detect_period, int):
                    response_data['message'] = "the param of detect_period must be integer"
                    response_data['chinese_message'] = "参数detect_period必须为整数类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if detect_period <= 0:
                    response_data['message'] = "the param of detect_period must be positive number"
                    response_data['chinese_message'] = "参数detect_period必须为正数"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

            if alarm_period is not None:
                if not isinstance(alarm_period, int):
                    response_data['message'] = "the param of alarm_period must be integer"
                    response_data['chinese_message'] = "参数alarm_period必须为整数类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
                if alarm_period <= 0:
                    response_data['message'] = "the param of alarm_period must be positive number"
                    response_data['chinese_message'] = "参数alarm_period必须为正数"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

            if fan_speed_min is not None:
                if not isinstance(fan_speed_min, int):
                    response_data['message'] = "the param of fan_speed_min must be integer"
                    response_data['chinese_message'] = "参数fan_speed_min必须为整数类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if fan_speed_min <= 0:
                    response_data['message'] = "the param of fan_speed_min must be positive number"
                    response_data['chinese_message'] = "参数fan_speed_min必须为正数"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

            if fan_speed_max is not None:
                if not isinstance(fan_speed_max, int):
                    response_data['message'] = "the param of fan_speed_max must be integer"
                    response_data['chinese_message'] = "参数fan_speed_max必须为整数类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
                if fan_speed_max <= 0:
                    response_data['message'] = "the param of fan_speed_max must be positive number"
                    response_data['chinese_message'] = "参数fan_speed_max必须为正数"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

            if board_temperature is not None:
                if not isinstance(board_temperature, float):
                    response_data['message'] = "the param of board_temperature must be float"
                    response_data['chinese_message'] = "参数board_temperature必须为浮点数类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
                if board_temperature <= 0:
                    response_data['message'] = "the param of board_temperature must be positive number"
                    response_data['chinese_message'] = "参数board_temperature必须为正数"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

            if temperature is not None:
                if not isinstance(temperature, float):
                    response_data['message'] = "the param of temperature must be float"
                    response_data['chinese_message'] = "参数temperature必须为浮点数类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
                if temperature <= 0:
                    response_data['message'] = "the param of temperature must be positive number"
                    response_data['chinese_message'] = "参数temperature必须为正数"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
            if cpu_rate is not None:
                if not isinstance(cpu_rate, float):
                    response_data['message'] = "the param of cpu_rate must be float"
                    response_data['chinese_message'] = "参数cpu_rate必须为浮点数类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if cpu_rate <= 0:
                    response_data['message'] = "the param of cpu_rate must be positive number"
                    response_data['chinese_message'] = "参数cpu_rate必须为正数"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

            if tpu_rate is not None:
                if not isinstance(tpu_rate, float):
                    response_data['message'] = "the param of tpu_rate must be float"
                    response_data['chinese_message'] = "参数tpu_rate必须为浮点数类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

                if tpu_rate <= 0:
                    response_data['message'] = "the param of tpu_rate must be positive number"
                    response_data['chinese_message'] = "参数tpu_rate必须为正数"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

            if disk_rate is not None:
                if not isinstance(disk_rate, float):
                    response_data['message'] = "the param of disk_rate must be float"
                    response_data['chinese_message'] = "参数disk_rate必须为浮点数类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

                if disk_rate <= 0:
                    response_data['message'] = "the param of disk_rate must be positive number"
                    response_data['chinese_message'] = "参数disk_rate必须为正数"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])

            if external_hard_disk_rate is not None:
                if not isinstance(external_hard_disk_rate, float):
                    response_data['message'] = "the param of external_hard_disk_rate must be float"
                    response_data['chinese_message'] = "参数external_hard_disk_rate必须为浮点数类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
                if external_hard_disk_rate <= 0:
                    response_data['message'] = "the param of external_hard_disk_rate must be positive number"
                    response_data['chinese_message'] = "参数external_hard_disk_rate必须为正数"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])
            #配置阈值
            if alarm_address_list is not None:
                alarm_address_string = ",".join(alarm_address_list)
                self.configdata.setConfig('ALARM_ADDRESS_LIST', alarm_address_string)
            if detect_period is not None:
                self.configdata.setConfig('DETECT_PERIOD', detect_period)
            if alarm_period is not None:
                self.configdata.setConfig('ALARM_PERIOD', alarm_period)

            if fan_speed_min is not None:
                self.configdata.setConfig('FAN_SPEED_MIN', fan_speed_min)
            if fan_speed_max is not None:
                self.configdata.setConfig('FAN_SPEED_MAX', fan_speed_max)
            if board_temperature is not None:
                self.configdata.setConfig('BOARD_TEMPERATURE', board_temperature)
            if temperature is not None:
                self.configdata.setConfig('TEMPERATURE', temperature)
            if cpu_rate is not None:
                self.configdata.setConfig('CPU_RATE', cpu_rate)
            if tpu_rate is not None:
                self.configdata.setConfig('TPU_RATE', tpu_rate)

            if disk_rate is not None:
                self.configdata.setConfig('DISK_RATE', disk_rate)
            if external_hard_disk_rate is not None:
                self.configdata.setConfig('EXTERNAL_HARD_DISK_RATE', external_hard_disk_rate)

            #获取已经配置的信息
            alarm_address_string = self.configdata.getItemConfig('ALARM_ADDRESS_LIST')
            detect_period = self.configdata.getItemConfig('DETECT_PERIOD')
            alarm_period = self.configdata.getItemConfig('ALARM_PERIOD')
            fan_speed_min = self.configdata.getItemConfig('FAN_SPEED_MIN')
            fan_speed_max = self.configdata.getItemConfig('FAN_SPEED_MAX')
            board_temperature = self.configdata.getItemConfig('BOARD_TEMPERATURE')
            temperature = self.configdata.getItemConfig('TEMPERATURE')
            cpu_rate = self.configdata.getItemConfig('CPU_RATE')
            tpu_rate = self.configdata.getItemConfig('TPU_RATE')

            disk_rate = self.configdata.getItemConfig('DISK_RATE')
            external_hard_disk_rate = self.configdata.getItemConfig('EXTERNAL_HARD_DISK_RATE')

            response_data['alarm_address_list'] = alarm_address_string.split(",")
            if "" in response_data['alarm_address_list']:
                response_data['alarm_address_list'].remove("")
            response_data['detect_period'] = detect_period
            response_data['alarm_period'] = alarm_period
            response_data['fan_speed_min'] = fan_speed_min
            response_data['fan_speed_max'] = fan_speed_max
            response_data['board_temperature'] = board_temperature
            response_data['temperature'] = temperature
            response_data['cpu_rate'] = cpu_rate
            response_data['tpu_rate'] = tpu_rate

            response_data['disk_rate'] = disk_rate
            response_data['external_hard_disk_rate'] = external_hard_disk_rate




            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SystemLogin(MethodView):
    def post(self, group_id=None, second_route=False):
        try:
            response_data={}
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json()
                username = content.get('username', None)
                password = content.get('password', None)

            elif content_type == 'multipart/form-data':
                username = request.form.get('username', None)
                password = request.form.get('password', None)
            else:
                username=None
                password=None

            #验证参数
            if username is None:
                response_data['message'] = "need the param of username"
                response_data['chinese_message'] = "缺少参数username"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

            if not isinstance(username,str):
                response_data['message'] = "the param of username must be string"
                response_data['chinese_message'] = "参数username必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],chinese_message=response_data['chinese_message'])

            if password is None:
                response_data['message'] = "need the param of password"
                response_data['chinese_message'] = "缺少参数password"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(password, str):
                response_data['message'] = "the param of password must be string"
                response_data['chinese_message'] = "参数password必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            script_path = os.path.realpath(__file__)
            script_dir = os.path.dirname(script_path)
            print ("test bokai")
            if run_in_docker():
                set_shell='/checkPasswd_docker.sh 127.0.0.1 %s %s'
            else :
                set_shell='/checkPasswd.sh 127.0.0.1 %s %s'

            cmd_str = script_dir + set_shell%(username,password)

            print(cmd_str)
            result,data = execShell(cmd_str)
            product = get_product()
            if data.find('Password is correct') > 0:
                return make_response({'success':True})
            elif data.find('Password is wrong') > 0:
                response_data['message'] = "username or password error  {} type".format(get_product())
                response_data['chinese_message'] = "账号或密码错误"
                if(product == "SE3"):
                    return make_response({'success':True})
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])
            else:
                _logger.info("===api login, cmd_str:{}".format(cmd_str))
                _logger.info("===api login, result:{},data:{}".format(result, data))
                return make_response({'success':True})
                #return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SystemPasswd(MethodView):
    def post(self, group_id=None, second_route=False):
        try:
            response_data = {}
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                username = content.get('username', None)
                old_password = content.get('old_password', None)
                new_password = content.get('new_password', None)

            elif content_type == 'multipart/form-data':
                username = request.form.get('username', None)
                old_password = request.form.get('old_password', None)
                new_password = request.form.get('new_password', None)
            else:
                username = None
                old_password = None
                new_password = None

            if username is None:
                response_data['message'] = "need the param of username"
                response_data['chinese_message'] = "缺少参数username"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(username, str):
                response_data['message'] = "the param of username must be string"
                response_data['chinese_message'] = "参数username必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if old_password is None:
                response_data['message'] = "need the param of old_password"
                response_data['chinese_message'] = "缺少参数old_password"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(old_password, str):
                response_data['message'] = "the param of old_password must be string"
                response_data['chinese_message'] = "参数old_password必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if new_password is None:
                response_data['message'] = "need the param of new_password"
                response_data['chinese_message'] = "缺少参数new_password"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(new_password, str):
                response_data['message'] = "the param of new_password must be string"
                response_data['chinese_message'] = "参数new_password必须为字符串"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            #做下密码限制
            for per_str in new_password:
                if u'\u4e00' <= per_str <= u'\u9fff':
                    response_data['message'] = "the param of new_password not contain chinese"
                    response_data['chinese_message'] = "参数new_password不能包含中文字符"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])


            script_path = os.path.realpath(__file__)
            script_dir = os.path.dirname(script_path)

            #先查询旧密码是否正确
            set_shell = '/checkPasswd.sh 127.0.0.1 %s %s'
            cmd_str = script_dir + set_shell % (username, old_password)

            result, data = execShell(cmd_str)
            if data.find('Password is wrong') > 0:
                response_data['message'] = "the param of old_password is wrong"
                response_data['chinese_message'] = "旧密码错误"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            set_shell='/changePasswd.sh %s %s'
            cmd_str = script_dir + set_shell%(username,new_password)

            result,data = execShell(cmd_str)
            if data.find('Changed Successful!') > 0:
                return make_response({'success':True})
            elif data.find('Change failed!') > 0:

                _logger.info("===api system_password, result:{},data:{}".format(result, data))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
            else:
                _logger.info("===api system_password, result:{},data:{}".format(result, data))
                return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class SystemStatus(MethodView):
    def __init__(self):
        self.configdata = ConfigDataSingletone()

    def get(self):
        response_data = {}

        try:
            monitor_address_list = self.configdata.getItemConfig("MONITOR_ADDRESS_LIST")
            report_period = self.configdata.getItemConfig("REPORT_PERIOD")
            dev_sno = self.configdata.getItemConfig("DEV_SNO")

            response_data['monitor_address_list'] = monitor_address_list.split(",")
            if "" in response_data['monitor_address_list']:
                response_data['monitor_address_list'].remove("")
            response_data['report_period']= report_period
            response_data['dev_sno']= dev_sno

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

        return make_response(response_data)


    def post(self, second_route=False):
        try:
            response_data ={}
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                monitor_address_list = content.get('monitor_address_list', list)
                report_period = content.get('report_period', None)
                dev_sno = content.get('dev_sno', None)

            elif content_type == 'multipart/form-data':
                monitor_address_list = request.form.get('monitor_address_list', list)
                report_period = request.form.get('report_period', None)
                dev_sno = request.form.get('dev_sno', None)

            else:
                return make_response(error='unsupported content_type')

            if monitor_address_list is None:
                response_data['message'] = "need the param of monitor_address_list"
                response_data['chinese_message'] = "缺少参数monitor_address_list"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(monitor_address_list, list):
                response_data['message'] = "the param of insecure_registries must be list"
                response_data['chinese_message'] = "参数insecure_registries必须为数组(列表)类型"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if report_period is None:
                response_data['message'] = "need the param of report_period"
                response_data['chinese_message'] = "缺少参数report_period"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(report_period, int):
                response_data['message'] = "the param of report_period must be integer"
                response_data['chinese_message'] = "参数report_period必须为整数类型"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if report_period <= 0:
                response_data['message'] = "the param of report_period must be positive number"
                response_data['chinese_message'] = "参数report_period必须为正数"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if dev_sno is not None:
                if not isinstance(dev_sno, str):
                    response_data['message'] = "the param of dev_sno must be string"
                    response_data['chinese_message'] = "参数dev_sno必须为字符串类型"
                    return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                               chinese_message=response_data['chinese_message'])



            if monitor_address_list:
                monitor_string = ",".join(monitor_address_list)
                self.configdata.setConfig('MONITOR_ADDRESS_LIST', monitor_string)
            self.configdata.setConfig('REPORT_PERIOD', report_period)
            self.configdata.setConfig('DEV_SNO', dev_sno)


            monitor_address_list = self.configdata.getItemConfig("MONITOR_ADDRESS_LIST")
            report_period = self.configdata.getItemConfig("REPORT_PERIOD")
            dev_sno = self.configdata.getItemConfig("DEV_SNO")

            response_data['monitor_address_list'] = monitor_address_list.split(",")
            if "" in response_data['monitor_address_list']:
                response_data['monitor_address_list'].remove("")
            response_data['report_period'] = report_period
            response_data['dev_sno'] = dev_sno

            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)

class SystemDocker(MethodView):
    def __init__(self):
        self.docker_file = "/etc/docker/daemon.json"

    def get(self):
        response_data = {}
        try:
            if not os.path.exists(self.docker_file):
                _logger.info("not found {}".format(self.docker_file))
                return make_error_response(ErrorResponseType.NOT_FOUND_FILE)

            #修改文件权限
            with open(self.docker_file, 'r', encoding='utf-8') as f:
                if not f.read():
                    response_data['insecure_registries'] = []
                    return make_response(response_data)


            with open(self.docker_file, 'r',encoding='utf-8') as f:
                data = json.load(f)
            response_data['insecure_registries'] = data['insecure-registries']
            # response_data['insecure_registries'] = insecure_registries.split(',')
            if "" in response_data['insecure_registries']:
                response_data['insecure_registries'].remove("")
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


        return make_response(response_data)

    def post(self, second_route=False):
        try:
            response_data ={}
            content_type = request.content_type.split(';')[0]
            if content_type == 'application/json':
                content = request.get_json(silent=True)
                insecure_registries = content.get('insecure_registries', list)

            elif content_type == 'multipart/form-data':
                insecure_registries = request.form.get('insecure_registries', list)

            else:
                return make_response(error='unsupported content_type')

            if insecure_registries is None:
                response_data['message'] = "need the param of insecure_registries"
                response_data['chinese_message'] = "缺少参数insecure_registries"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            if not isinstance(insecure_registries, list):
                response_data['message'] = "the param of insecure_registries must be list"
                response_data['chinese_message'] = "参数insecure_registries必须为数组(列表)类型"
                return make_error_response(ErrorResponseType.PARAM_ERROR, message=response_data['message'],
                                           chinese_message=response_data['chinese_message'])

            docker_file = "/etc/docker/daemon.json"

            data = {
                "insecure-registries":insecure_registries
            }

            with open(docker_file, 'w',encoding='utf-8') as f:
                json.dump(data, f)

            #重启docker
            cmd_str = "systemctl restart docker"

            result, data = execShell(cmd_str)

            if result != 0:
                _logger.info("restart docker failed = {}".format(data))
                return make_error_response(ErrorResponseType.RESTART_DOCKER_ERROR)

            response_data['insecure_registries']=insecure_registries
            if "" in response_data['insecure_registries']:
                response_data['insecure_registries'].remove("")
            return make_response(response_data)
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


class SystemExternalDisk(MethodView):
    def get(self):
        response_data = {}
        response_data['external_hard_state'] = "0"
        response_data['external_hard_total_disk'] = "0G"
        response_data['external_hard_used_disk'] = "0G"
        response_data['external_hard_free_disk'] = "0G"
        response_data['external_hard_disk_rate'] = 0.0

        try:
            response_data = system_fun.getExternalDisk()
            return make_response(response_data)

        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)


def set_restful_api(blueprint, view, route_name, route_id, second_route_name=None, second_route_id=None, view_kwargs={}, list_all=False):
    view_func = view.as_view('{}_api'.format(route_name), **view_kwargs)

    # GET /resources
    blueprint.add_url_rule(
        '/{}'.format(route_name),
        view_func=view_func,
        defaults={'list_all': True} if list_all else {},
        methods=['GET', 'PUT','DELETE']
    )

    # POST /resources
    blueprint.add_url_rule(
        '/{}'.format(route_name),
        view_func=view_func,
        methods=['POST']
    )

    # GET/PUT /resources/<resource_id>
    blueprint.add_url_rule(
        '/{}/<string:{}>'.format(route_name, route_id),
        view_func=view_func,
        methods=['GET', 'PUT', 'DELETE']
    )

    if second_route_name is None or second_route_id is None:
        return

    # POST/DELETE /resources/<resource_id>/second_resources
    blueprint.add_url_rule(
        '/{}/<string:{}>/{}'.format(route_name, route_id, second_route_name),
        view_func=view_func,
        defaults={'second_route': True},
        methods=['GET','POST', 'DELETE']
    )
    # DELETE /resources/<resource_id>/second_resources/<second_resource_id>
    blueprint.add_url_rule(
        '/{}/<string:{}>/{}/<string:{}>'.format(route_name, route_id, second_route_name, second_route_id),
        view_func=view_func,
        defaults={'second_route': True},
        methods=['DELETE']
    )


class ApiServer(object):
    def __init__(self, video_service=None, debug=False,is_config_blueprint=True):

        if not is_config_blueprint:
            self.blueprint = Blueprint('systemapi', __name__)
        else:
            self.blueprint = Blueprint('systemapi_config', __name__)

        #for system restful apik
        set_restful_api(
            self.blueprint, SystemIP, 'ip',None,
        )

        set_restful_api(
            self.blueprint, SystemHostname, 'hostname',None,
        )
        set_restful_api(
            self.blueprint, SystemTemperature, 'temperature',None,
        )
        set_restful_api(
            self.blueprint, SystemTpuRate, 'tpu',None,
        )
        set_restful_api(
            self.blueprint, SystemCpuRate, 'cpu',None,
        )
        set_restful_api(
            self.blueprint, SystemTime, 'time', None,
        )

        # set_restful_api(
        #     self.blueprint, CopyDataToSD, 'export', None,
        # )
        # set_restful_api(
        #     self.blueprint, DeviceType, 'deviceType',None,
        # )
        set_restful_api(
            self.blueprint, DeviceSN, 'deviceSN',None,
        )             
        set_restful_api(
            self.blueprint, SystemVersion, 'systemVersion',None,
        )     
        # set_restful_api(
        #     self.blueprint, DetailSWVersion, 'detailSWVersion',None,
        # )
        # set_restful_api(
        #     self.blueprint, SwitchOtaType, 'switchOtaType',None,
        #
        # )
        # set_restful_api(
        #     self.blueprint, PublicOtaVersion, 'publicOtaVersion', None,
        # )
        # set_restful_api(
        #     self.blueprint, PrivateOtaUrl, 'privateOtaUrl',None,
        # )
        # set_restful_api(
        #     self.blueprint, OtaUpdated, 'otaUpdate',None,
        # )
        set_restful_api(
            self.blueprint, LocalUpdate, 'localUpdate',None,
        )
        # set_restful_api(
        #     self.blueprint, PublicOtaUrl, 'publicOtaUrl',None,
        # )
        set_restful_api(
            self.blueprint, SystemTimeMode, 'timeSelectMode', None
        )
        set_restful_api(
            self.blueprint, NtpConfig, 'ntpConfig', None
        )        
        set_restful_api(
            self.blueprint, LocalUpdateUploadFile, 'LocalUpgrade', None,
        )
        set_restful_api(
            self.blueprint, SystemFan, 'fan', None,
        )
        set_restful_api(
            self.blueprint, SystemUptime, 'uptime', None,
        )
        # set_restful_api(
        #     self.blueprint, SystemMonitor, 'monitor', None,
        # )

        # set_restful_api(
        #     self.blueprint, SystemBasicInfo, 'basicinfo', None,
        # )
        set_restful_api(
            self.blueprint, SystemLogin, "login", None,
        )
        set_restful_api(
            self.blueprint, SystemPasswd, "password", None,
        )
        set_restful_api(
            self.blueprint, SystemRegularReboot, "regularReboot", None,
        )
        set_restful_api(
            self.blueprint, SystemMode, "systemMode", None,
        )
        set_restful_api(
            self.blueprint, SystemDisk, 'diskInfo', None,
        )

        set_restful_api(
            self.blueprint, SystemExternalDisk, 'externalDiskInfo', None,
        )

        set_restful_api(
            self.blueprint, SystemLogs, 'logs', None,
        )

        set_restful_api(
            self.blueprint, SystemMemory, 'memoryInfo', None,
        )

        set_restful_api(
            self.blueprint, SystemHardwareInfo, 'hardwareInfo', None,
        )

        set_restful_api(
            self.blueprint, SystemRtmp, 'transformRtmp', None,
        )

        set_restful_api(
            self.blueprint, SystemLteModem, 'lteModem', None,
        )

        set_restful_api(
            self.blueprint, SystemLteModemSelection, 'lteModemSelection', None,
        )
        set_restful_api(
            self.blueprint, SystemLteModemConnect, 'lteModemConnection', None,
        )
        set_restful_api(
            self.blueprint, SystemLteModemSimStatus, 'lteModemSimStatus', None,
        )

        #set_restful_api(
        #    self.blueprint, SystemAlarm, 'alarm', None,
        #)

        #set_restful_api(
        #    self.blueprint, SystemDocker, 'docker', None,
        #)

        set_restful_api(
            self.blueprint, SystemStatus, 'monitor', None,
        )


# def get_systemapi_blueprint(mode=DEFAULT_MODE, mongo_ip='localhost', debug=False, output=None,is_config_blueprint=True):
def get_systemapi_blueprint(mongo_ip='localhost', debug=False, output=None,is_config_blueprint=True):

    if is_config_blueprint:

        api_server = ApiServer(
            debug=debug,
            is_config_blueprint=False
        )

        config_api_server = ApiServer(
            debug=debug,
            is_config_blueprint=True
        )

        return api_server.blueprint,config_api_server.blueprint
    else:
        api_server = ApiServer(
            debug=debug,
            is_config_blueprint=False
        )
        return api_server.blueprint
