
from system_misc import make_error_response,ErrorResponseType,get_product
import logger
import abc
from system_factory_Abstract import AbstractSystemFactory
from system_SE3 import SE3SystemFactory
from system_SE5 import SE5SystemFactory

build_info_path = '/opt/data/buildinfo.txt'
config_ntp = '/etc/systemd/timesyncd.conf'
device_type_info = '/sys/kernel/debug/memblock/memory'
ota_config_path = '/data/ota/otaconfig.ini'

_logger = logger.getLogger("SystemServer")

class ProductFactory():
    def CreateProduct(product_type):
        if product_type == "SE3":
            ProductFunction = SE3SystemFactory()
        elif product_type == "SE5":
            ProductFunction = SE5SystemFactory()
        else:
            ProductFunction = SE5SystemFactory()
        return ProductFunction

class SystemFunction(AbstractSystemFactory):
    def __init__(self):
        product_type = get_product()
        self.ProductFunction = ProductFactory.CreateProduct(product_type)
    def getBoxVersion(self):
        pass;
    def getSystemTemperature(self):
        return self.ProductFunction.getSystemTemperature()
    def getIP(self):
        return self.ProductFunction.getIP()
    def setIP(self,eth_dev,ip_info):
        pass;
    def getSystemVersion(self):
        return self.ProductFunction.getSystemVersion()
    def getTpuData(self):
        return self.ProductFunction.getTpuData()
    def getCpuRate(self):
        pass;
    def getDeviceSN(self):
        return self.ProductFunction.getDeviceSN()
    def getSystemFan(self):
        return self.ProductFunction.getSystemFan()
    def getSystemHardwareInfo(self):
        return self.ProductFunction.getSystemHardwareInfo()
    def getSystemMemory(self):
        return self.ProductFunction.getSystemMemory()

    def getSystemDisk(self):
        return self.ProductFunction.getSystemDisk()

    def getCpuData(self):
        return self.ProductFunction.getCpuData()

    def getHostName(self):
        return self.ProductFunction.getHostName()

    def getUptime(self):
        return self.ProductFunction.getUptime()

    def getExternalDisk(self):
        return self.ProductFunction.getExternalDisk()
