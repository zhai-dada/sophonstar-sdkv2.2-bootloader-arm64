#!/bin/bash

mount -o remount,rw /

#clear 
sed -i "/CUSTOMER CMD reboot FOR BITMAIN/d" /etc/crontab

sudo systemctl restart cron

mount -o remount,ro /


