import logging
import threading
import yaml
import logging.config
import os
import glv

initLock = threading.Lock()
rootLoggerInitialized = False
filetime = None

log_format = "%(asctime)s %(process)d-%(thread)d %(name)s [%(levelname)s] %(message)s"
level = logging.DEBUG
file_log = "/data/log/SophonGate.log"  # File name
console_log = True
yaml_path = "/bm_services/sophon_system/Util/logging.yaml" 


def setup_logging(default_path='logging.yaml', default_level=logging.INFO):
    path = default_path
    if os.path.exists(path):
        with open(path, 'rt') as f:
            config = yaml.safe_load(f.read())
        logging.config.dictConfig(config)
    else:
        logging.basicConfig(level = default_level)

def timer_handler():
    global filetime
    try:
        setting_time = os.path.getmtime(yaml_path)
        if setting_time != filetime:
            setup_logging(yaml_path)
            filetime = setting_time
    except Exception as e:
        logging.getLogger().exception(e)
    global timer
    timer = threading.Timer(30, timer_handler)
    timer.start()

def init_handler(handler):
    handler.setFormatter(Formatter(log_format))


def init_logger(logger):
    # logger.setLevel(level)
    # if file_log is not None:
    #     fileHandler = logging.FileHandler(file_log)
    #     init_handler(fileHandler)
    #     logger.addHandler(fileHandler)
    #
    # if console_log:
    #     consoleHandler = logging.StreamHandler()
    #     init_handler(consoleHandler)
    #     logger.addHandler(consoleHandler)
    setup_logging(yaml_path)


def initialize():
    global rootLoggerInitialized
    global filetime
    with initLock:
        if not rootLoggerInitialized:
            filetime = os.path.getmtime(yaml_path)
            init_logger(logging.getLogger())
            timer_handler()
            rootLoggerInitialized = True


def getLogger(name=None):
    initialize()
    my_logger = logging.getLogger(name)
    return my_logger


# This formatter provides a way to hook in formatTime.
class Formatter(logging.Formatter):
    DATETIME_HOOK = None

    def formatTime(self, record, datefmt=None):
        newDateTime = None

        if Formatter.DATETIME_HOOK is not None:
            newDateTime = Formatter.DATETIME_HOOK()

        if newDateTime is None:
            ret = logging.Formatter.formatTime(self, record, datefmt)
        else:
            ret = str(newDateTime)
        return ret

class RotatingFileHandlerByPID(logging.handlers.RotatingFileHandler):
    def __init__(self, filename, mode='a', maxBytes=0, backupCount=0, encoding=None, delay=False):
        '''

        '''
        pid = os.getpid()
        name = glv.get_value("LOG_FILE", "/data/log/SDKDefault.log")
        #print("RotatingFileHandlerByPID: pid: %s,  name: %s" % (pid, name))
        super().__init__(name, mode, maxBytes, backupCount, encoding, delay)

def main():
    log = getLogger()
    log.info("this is info test")
    log.debug("this is just debug test")
    log.error("this is error test")

if __name__ == '__main__':
    main()
