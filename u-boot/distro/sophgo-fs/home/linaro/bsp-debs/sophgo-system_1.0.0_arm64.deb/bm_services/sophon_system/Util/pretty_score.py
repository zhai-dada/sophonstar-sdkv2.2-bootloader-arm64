from ConfigDataSingletone import ConfigDataSingletone
import logger
import os
import shutil
import psutil
import fcntl
import _thread

class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

class PrettyScore(metaclass=Singleton):
    def __init__(self):
        self.configdata = ConfigDataSingletone()
        self._logger = logger.getLogger("pretty_score")
        self.box_start_score = 0
        self.box_best_score = 0.5
        self.box_max_score = 1

    #二元一次方程式假定为y = ax + b
    def set_the_math_func_params(self,start_score, best_score, max_score):

        try:
            start_score = float(start_score)
            best_score = float(best_score)
            max_score = float(max_score)

            #第一段方程式的斜率和交点,都是浮点数，确保精度
            first_score_func_a = (best_score - start_score) / (self.box_best_score - self.box_start_score)
            first_score_func_b = (start_score*self.box_best_score - best_score*self.box_start_score) / (self.box_best_score - self.box_start_score)

            #第二段方程式的斜率和交点，都是浮点数，确保精度
            second_score_func_a = (max_score - best_score) / (self.box_max_score - self.box_best_score)
            second_score_func_b = (best_score * self.box_max_score - max_score*self.box_best_score) / (self.box_max_score - self.box_best_score)

            self.configdata.setConfig("FIRST_SCORE_FUNC_A",first_score_func_a)
            self.configdata.setConfig("FIRST_SCORE_FUNC_B",first_score_func_b)
            self.configdata.setConfig("SECOND_SCORE_FUNC_A",second_score_func_a)
            self.configdata.setConfig("SECOND_SCORE_FUNC_B",second_score_func_b)

        except Exception as e:
            self._logger.exception(e)
            return False

        return True

    #利用已经算出的折射关系，将分数进行转化返回
    def pretty_the_socre(self,box_score):
        box_score = float(box_score)
        finally_score = 0.0
        try:

            #分数小于盒子最佳分数0.5，就是第一段折线
            if box_score < self.box_best_score:
                first_score_func_a = self.configdata.getItemConfig("FIRST_SCORE_FUNC_A")
                first_score_func_b = self.configdata.getItemConfig("FIRST_SCORE_FUNC_B")

                finally_score = first_score_func_a * box_score + first_score_func_b
            else:
                second_score_func_a = self.configdata.getItemConfig("SECOND_SCORE_FUNC_A")
                second_score_func_b = self.configdata.getItemConfig("SECOND_SCORE_FUNC_B")

                finally_score = second_score_func_a * box_score + second_score_func_b
        except Exception as e:
            self._logger.exception(e)

        return finally_score

    #把管理平台下放的分数转为小盒子上的分数
    def get_box_score(self, pretty_score):
        pretty_score = float(pretty_score)
        box_score = 0.0
        try:

            # 分数小于盒子最佳分数0.5，就是第一段折线
            threshold_range_str = self.configdata.getItemConfig("THRESHOLD_RANGE")
            threshold_range_list = threshold_range_str.split(',')

            pretty_start_score = float(threshold_range_list[0])
            pretty_best_score = float(threshold_range_list[1])
            pretty_max_score = float(threshold_range_list[2])

            if pretty_score >= pretty_start_score and pretty_score < pretty_best_score:
                first_score_func_a = self.configdata.getItemConfig("FIRST_SCORE_FUNC_A")
                first_score_func_b = self.configdata.getItemConfig("FIRST_SCORE_FUNC_B")

                box_score = (pretty_score - first_score_func_b) / first_score_func_a
            elif pretty_score <= pretty_max_score:
                second_score_func_a = self.configdata.getItemConfig("SECOND_SCORE_FUNC_A")
                second_score_func_b = self.configdata.getItemConfig("SECOND_SCORE_FUNC_B")

                box_score = (pretty_score - second_score_func_b) / second_score_func_a
        except Exception as e:
            self._logger.exception(e)

        return box_score