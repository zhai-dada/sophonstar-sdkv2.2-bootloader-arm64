#!/bin/bash
mount -o remount,rw /
systemctl enable systemd-timesyncd
systemctl restart systemd-timesyncd
mount -o remount,ro /
