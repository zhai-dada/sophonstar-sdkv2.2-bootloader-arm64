#!/bin/bash

#clear 
sed -i "/CUSTOMER CMD reboot FOR BITMAIN/d" /etc/crontab

sudo systemctl restart cron



