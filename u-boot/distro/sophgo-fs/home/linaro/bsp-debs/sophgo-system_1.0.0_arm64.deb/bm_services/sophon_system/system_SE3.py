import os
import base64
import time
import datetime
import requests
import flask
import shutil
from non_volatile_config import NonVolatileConfigParser
import re
import hashlib
import tarfile
import zipfile
import threading
import subprocess
import socket
import netifaces

from threading import Thread, Lock
from http import HTTPStatus
from flask import request,jsonify
from flask import Blueprint, render_template, send_from_directory
from flask.views import MethodView
# from sophonface import Mode, DEFAULT_MODE,Product
from distutils.util import strtobool
from requests.exceptions import ConnectionError
import psutil
from system_misc import make_error_response,ErrorResponseType,get_pretty_result
# from running_state import run_in_docker
import logger
import abc
import subprocess
from system_factory_Abstract import AbstractSystemFactory
from system_misc import execShell,get_ip_implement
build_info_path = '/opt/data/buildinfo.txt'
config_ntp = '/etc/systemd/timesyncd.conf'
device_type_info = '/sys/kernel/debug/memblock/memory'
ota_config_path = '/data/ota/otaconfig.ini'

_logger = logger.getLogger("SystemServer")



class SE3SystemFactory(AbstractSystemFactory):
    __metaclass__=abc.ABCMeta
    def getBoxVersion(self):
        try:
            version = ''
            with open(build_info_path) as f:
                line = f.readlines()
                for textLine in line:
                    if textLine.find('VERSION')>=0:
                        version = textLine.split(':')[1].strip('\n').strip()
                        break
            if version:
                return version
            else:
                raise FileNotFoundError
        except FileNotFoundError:
            return ''
    def getSystemTemperature(self):
        script_path = os.path.realpath(__file__)
        script_dir = os.path.dirname(script_path)
        cmd_str= script_dir + '/get_C_SE3.sh'
        err1, temperature = execShell(cmd_str)

        if err1 == 0:
            #取出主板温度和芯片温度
            board_temperature = float(re.search(".*?(\d+).*?(\d+).*?",temperature).group(1))
            core_temperature = float(re.search(".*?(\d+).*?(\d+).*?",temperature).group(2))
            return board_temperature,core_temperature
        else:
            return 0,0

    def getIP(self):
        try:
            err1, wanspeed = execShell("ethtool eth0 | grep Speed | awk '{print $2}'")
            err2, mac1 = execShell("cat /sys/class/net/eth0/address")
            print(wanspeed)
            wanYes = False

            if "1000Mb" in wanspeed:
                wanYes = True
            res_0 = get_ip_implement('eth0')
            res = list()
            res_0['bandwidth']= wanspeed
            res_0['bandwidth_varity']= wanYes
            res_0['mac'] = mac1
            res.append(res_0)
            res_1={}
            res_1['bandwidth']= "N/A"
            res_1['bandwidth_varity']= False
            res_1['mac'] = ""
            res_1['dns'] = ' '
            res_1['ip'] = 'N/A'
            res_1['mac'] = ' '
            res_1['netmask'] = ' '
            res_1['status'] = 'dynamic'
            #res.append(res_1)

            
            print(res)
            return res
        except Exception as e:
            _logger.exception(e)
            return None

    def setIP(self,eth_dev,ip_info):
        pass;
    def getSystemVersion(self):
        response_data={}
        version = self.getBoxVersion()
        mcu_version="N/A"
        #获取details
        buildinfo_xml_file = "//data/buildinfo.xml"
        detail_xml_string = ""
        with open(buildinfo_xml_file,"r") as fp:
            line = fp.readlines()
            for textLine in line:
                if textLine.find('project') >= 0:
                    per_name=re.search(".*?name=\"(.*?)\"",textLine).group(1)
                    per_path=re.search(".*?path=\"(.*?)\"",textLine).group(1)
                    per_revision=re.search(".*?revision=\"(.*?)\"",textLine).group(1)
                    per_upstream=re.search(".*?upstream=\"(.*?)\"",textLine).group(1)
                    per_dest_branch=re.search(".*?dest-branch=\"(.*?)\"",textLine).group(1)
                    per_groups=re.search(".*?groups=\"(.*?)\"",textLine).group(1)
                    perline_sring = "name:{} path:{} revision:{} upstream:{} dest-branch:{} groups:{}<br/>".format(per_name,per_path,per_revision,per_upstream,per_dest_branch,per_groups)
                    detail_xml_string += perline_sring
        response_data['version'] = version
        response_data['mcu_version'] = mcu_version
        response_data['details'] = detail_xml_string
        return response_data
    def getTpuData(self):
        tpu_data = {}
        tpu_data['info'] = {"detail":"FP32 3.0 TFLOPS"}
        execShell("echo 1 > /sys/class/bm-npu/bm-npu0/device/npu_usage_enable")
        time.sleep(2)
        err1, tpurate = execShell("cat /sys/devices/platform/0.bmtpu/npu_usage")
        if err1 != 0:
            _logger.info("===api tpurate, result:{},tpurate:{}".format(err1, tpurate))
            tpu_data['tpu_rate'] = 0;
            return tpu_data
            #return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
        tpurate = re.search(".*?(\d+).*?(\d+).*?",tpurate).group(1)
        tpurate = round((float(tpurate)/100),2)
        tpu_data['tpu_rate'] = tpurate;
        return tpu_data
    def getDeviceSN(self):
        device_sn = '/sys/class/bm_efuse/bm_efuse/sn'
        try:
            with open(device_sn) as f:
                line = f.readlines()
                print(line)
                SN_all = line[0].split(',')[0]
                SN = str(SN_all.split(':')[1])
                return SN
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)
    def getCpuRate(self):
        pass
    def getSystemFan(self):
        fan = '/sys/class/pwm/pwmchip0/pwm0/duty_cycle'

        with open(fan, 'r') as f:
            emptyRatioStr = f.readlines()[0].strip('\n').strip()
            emptyRatio = int(emptyRatioStr)
        if emptyRatio < 0:
            return make_error_response(ErrorResponseType.EXCELL_SCRIPTS_ERROR)

        x = (50000 - emptyRatio) / 50000 * 100 - 20
        if x > 20:
            fan_rate = int(4500 * x / 80 + 1000)
        else:
            fan_rate = 1000
        return fan_rate
    def getSystemHardwareInfo(self):
        device_sn = '/sys/class/bm_efuse/bm_efuse/sn'
        try:
            with open(device_sn) as f:
                line = f.readlines()
                print(line)
                SN_all = line[0].split(',')[0]
                device_sn = str(SN_all.split(':')[1])
                chip_sn = device_sn
                model = 'SE3'
                product_version = '1'
                return model,product_version,device_sn,chip_sn
        except Exception as e:
            _logger.exception(e)
            return make_error_response(ErrorResponseType.SERVER_ERROR)
    def getSystemMemory(self):
        response_data = {}
        err1, memory = execShell("free -m | grep Mem | awk '{printf $2\";\"$3\";\"$7}'")
        total_system = memory.split(";")[0]
        used_system = memory.split(";")[1]
        #free_system = memory.split(";")[2]
        used_system_std = round(float(used_system), 2)
        total_system_std = round(float(total_system) , 2)
        free_system_std = round(float(total_system_std-used_system_std) , 2)

        err1, memory = execShell("head -3 /sys/kernel/debug/ion/bm_carveout_heap_dump | grep carveout")
        memory = memory.split(':')
        total_npu = memory[1].split(' ')[0]
        used_npu = memory[2].split(' ')[0]
        #ToBeDone
        #total_npu = 0
        #used_npu = 0
        free_npu = int(total_npu) - int(used_npu)
        total_npu = round(float(total_npu) / 1024.0 / 1024.0, 2)
        used_npu = round(float(used_npu) / 1024.0 / 1024.0, 2)
        free_npu = round(float(free_npu) / 1024.0 / 1024.0, 2)
        print(total_npu)
        print(used_npu)
        print(free_npu)

        err1, memory = execShell("cat /sys/kernel/debug/ion/bm_vpu_heap_dump/summary | grep 'vpu heap size'")
        total_vpu = 0
        used_vpu = 0
        free_vpu = 0
        if len(memory) > 100 and err1 == 0:
            memory = memory.split(':')
            total_vpu = memory[1].split(' ')[0]
            used_vpu = memory[2].split(' ')[0]
            free_vpu = int(total_vpu) - int(used_vpu)
            total_vpu = round(float(total_vpu) / 1024.0 / 1024.0, 2)
            used_vpu = round(float(used_vpu) / 1024.0 / 1024.0, 2)
            free_vpu = round(float(free_vpu) / 1024.0 / 1024.0, 2)

        #err1, memory = execShell("cat /sys/kernel/debug/ion/bm_vpp_heap_dump/summary | grep 'vpp heap size'")
        #memory = memory.split(':')
        #total_vpp = memory[1].split(' ')[0]
        #used_vpp = memory[2].split(' ')[0]
        #ToBeDone
        total_vpp = 0
        used_vpp = 0
        free_vpp = int(total_vpp) - int(used_vpp)
        total_vpp = round(float(total_vpp) / 1024.0 / 1024.0, 2)
        used_vpp = round(float(used_vpp) / 1024.0 / 1024.0, 2)
        free_vpp = round(float(free_vpp) / 1024.0 / 1024.0, 2)

        #总得统计
        total_memory_all = round((total_system_std + total_npu + total_vpu + total_vpp),2)
        free_memory_all = round((free_system_std + free_npu + free_vpu + free_vpp),2)
        used_memory_all = round((used_system_std + used_npu + used_vpu + used_vpp),2)
        response_data['hardware_total_memory'] = get_pretty_result(8*1024.0)
        response_data['total_memory']= get_pretty_result(total_memory_all)
        response_data['total_free_memory']=get_pretty_result(free_memory_all)
        response_data['total_used_memory']=get_pretty_result(used_memory_all)
        response_data['total_memory_scale'] = round((used_memory_all / total_memory_all), 2)
        response_data['system'] = {}
        response_data['system']['total']= get_pretty_result(total_system_std)
        response_data['system']['free']=get_pretty_result(free_system_std)
        response_data['system']['used']=get_pretty_result(used_system_std)
        response_data['system']['system_scale']= round((total_system_std / total_memory_all),2)
        response_data['tpu']={}
        response_data['tpu']['total']=get_pretty_result(total_npu)
        response_data['tpu']['free']=get_pretty_result(free_npu)
        response_data['tpu']['used']=get_pretty_result(used_npu)
        response_data['tpu']['tpu_scale'] = round((total_npu / total_memory_all),2)
        response_data['video'] = {}
        response_data['video']['total']=get_pretty_result(total_vpu+total_vpp)
        response_data['video']['free']=get_pretty_result(free_vpu+free_vpp)
        response_data['video']['used']=get_pretty_result(used_vpu+used_vpp)
        response_data['video']['video_scale'] = round(((total_vpu+total_vpp) / total_memory_all), 2)

        return response_data

    def getSystemDisk(self):
        response_data = {}
        err1, total_disk_size = execShell("fdisk -l | grep mmcblk0: | awk '{print $5}'")
        if err1 != 0:
            _logger.info("===api SystemDisk, result:{},total_disk_size:{}".format(err1, total_disk_size))

        err2, data_disk_size = execShell("df -m | grep /dev/mmcblk0p7 | awk '{printf $2\";\"$4}'")
        if err2 != 0:
            _logger.info("===api SystemDisk, result:{},data_disk_size:{}".format(err2, data_disk_size))

        total_data_disk_size = total_disk_size.split(";")[0]
        free_data_disk_size = data_disk_size.split(";")[1]
        total_data_disk_size_std = round(float(total_data_disk_size) / 1000.0 / 1000.0, 2)
        free_data_disk_size_std = round(float(free_data_disk_size), 2)
        response_data['hardware_total_disk'] = get_pretty_result(32 * 1024.0)

        used_data_disk_size_std = round((total_data_disk_size_std - free_data_disk_size_std), 2)
        disk_rate = round((used_data_disk_size_std / total_data_disk_size_std), 2)

        response_data['total_disk'] = get_pretty_result(total_data_disk_size_std)
        response_data['free_disk'] = get_pretty_result(free_data_disk_size_std)
        response_data['used_disk'] = get_pretty_result(used_data_disk_size_std)
        response_data['disk_rate'] = disk_rate
        return response_data

    def getCpuData(self):
        response_data = {}
        cpustat_list = psutil.cpu_percent(percpu=True)
        all_used_cpu_rate = 0
        for per_cpu_rate in cpustat_list:
            all_used_cpu_rate += per_cpu_rate

        cpustat = round(float(all_used_cpu_rate / (psutil.cpu_count() * 100)), 2)

        # cpu频率
        cpu_freq_info = psutil.cpu_freq().current

        # cpu核数
        cpu_count_info = psutil.cpu_count()

        base_info = {}
        base_info['cpu_freq'] = str(round((cpu_freq_info / 1000000), 2)) + "Ghz"
        base_info['cpu_count'] = str(cpu_count_info)
        base_info['cpu_type'] = "A53"

        response_data = {'cpu_rate': cpustat,"info":base_info}
        return response_data

    def getHostName(self):
        response_data = {}
        err1, hostname = execShell("hostname")

        if err1 != 0:
            _logger.info("===api hostname, result:{},hostname:{}".format(err1, hostname))

        response_data = {'hostname': hostname}
        return response_data

    def getUptime(self):
        response_data = {}
        err1, uptimeInfo = execShell('uptime --pretty')

        if err1 != 0:
            _logger.info("===api uptime, result:{},data:{}".format(err1, uptimeInfo))

        # cut 'up' in string like 'up 4hours, 5minutes'
        uptimeInfo = uptimeInfo[3:].strip()
        response_data = {'uptime': uptimeInfo}
        return response_data

    def getExternalDisk(self):
        response_data = {}
        response_data['external_hard_state'] = "0"
        response_data['external_hard_total_disk'] = "0G"
        response_data['external_hard_used_disk'] = "0G"
        response_data['external_hard_free_disk'] = "0G"
        response_data['external_hard_disk_rate'] = 0.0
        all_disk_info = psutil.disk_partitions()
        # 固定返回mount为/data2
        for per_disk_info in all_disk_info:
            if per_disk_info.mountpoint == "/data2":
                external_hard_drive_info_class = psutil.disk_usage("/data2")
                external_total = round(external_hard_drive_info_class.total / (1000.0 * 1000.0), 2)
                external_used = round(external_hard_drive_info_class.used / (1000.0 * 1000.0), 2)
                external_free = round(external_hard_drive_info_class.free / (1000.0 * 1000.0), 2)
                external_percent = round(external_hard_drive_info_class.percent / (1000.0 * 1000.0), 2)

                response_data['external_hard_state'] = "1"
                response_data['external_hard_total_disk'] = get_pretty_result(external_total)
                response_data['external_hard_used_disk'] = get_pretty_result(round(external_total - external_free, 2))
                response_data['external_hard_free_disk'] = get_pretty_result(external_free)
                response_data['external_hard_disk_rate'] = round(((external_total - external_free) / external_total), 2)

        return response_data
