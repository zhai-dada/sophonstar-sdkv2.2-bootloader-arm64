from ConfigDataSingletone import ConfigDataSingletone
import logger
import os
import shutil
import psutil
import fcntl
import _thread
import queue
import time
from threading import Thread
custom_thread_name = False
if custom_thread_name:
	import prctl
class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

class EventImageSave(metaclass=Singleton):
    def __init__(self):
        self.configdata = ConfigDataSingletone()
        self.event_image_logger = logger.getLogger("event_image")
        self.origin_image_folder = self.configdata.getItemConfig("EVENT_IMAGE_PATH")
        try:
            if not os.path.exists(self.origin_image_folder):
                os.makedirs(self.origin_image_folder)
                os.chmod(self.origin_image_folder, 0o777)
        except Exception as e:
            self.event_image_logger.exception(e)

        self.second_dir_time = 3600
        self.lock = _thread.allocate_lock()

        self.image_queue = queue.Queue()
        self.write_image_running = False
        self.write_image_t = Thread(target = self.write_image_thread)
        self.write_image_t.start()

    def write_image_thread(self):
        if custom_thread_name:
            prctl.set_name("ImageToFile")
        self.write_image_running = True
        while(self.write_image_running):
            try:
                path, belong_image_folder, image_byte = self.image_queue.get()

                with self.lock:
                    if not os.path.exists(belong_image_folder):
                        os.makedirs(belong_image_folder)
                        os.chmod(belong_image_folder, 0o777)

                with open(path, 'wb') as fp:
                    fcntl.flock(fp, fcntl.LOCK_EX)
                    fp.write(image_byte)
                    fcntl.flock(fp, fcntl.LOCK_UN)
                del image_byte
            except Exception as e:
                self.event_image_logger.info('[write_image_thread] error {}'.format(e))

    def save(self, image_id,image_byte, event_time, image_type='jpg'):
        result = True
        origin_image_path = ''
        try:
            per_image_name = image_id + "." + image_type

            # 创建二级目录，秒级时间戳
            second_dir = str(int(event_time/(self.second_dir_time)))

            #三级目录名
            belong_image_folder_name = image_id[0:2]
            #最终目录拼接
            second_dir_path =  os.path.join(self.origin_image_folder,second_dir)
            belong_image_folder = os.path.join(second_dir_path,belong_image_folder_name)

            origin_image_path = os.path.join(belong_image_folder, per_image_name)
            self.image_queue.put([origin_image_path, belong_image_folder, image_byte])
        except Exception as e:
            result = False
            self.event_image_logger.exception(e)         
        return result, origin_image_path


    # #删除某一张图片
    def delete(self, image_id=None, event_time = None, image_path=None, image_type='jpg'):
        result = True
        try:
            origin_image_path = None
            if image_id is not None:
                per_image_name = image_id + "." + image_type

                # 创建二级目录，秒级时间戳
                second_dir = str(int(event_time / (self.second_dir_time)))
                # 三级目录名
                belong_image_folder_name = image_id[0:2]
                # 最终目录
                second_dir_path = os.path.join(self.origin_image_folder, second_dir)

                belong_image_folder = os.path.join(second_dir_path, belong_image_folder_name)
                origin_image_path = os.path.join(belong_image_folder, per_image_name)

            elif image_path is not None:
                origin_image_path = image_path
            if origin_image_path is not None:
                os.remove(origin_image_path)
        except Exception as e:
            result = False
            self.event_image_logger.exception(e)
        return result


    def getImage(self, image_id,event_time, image_type='jpg'):
        origin_image_binary = b''
        try:
            if image_id is not None:
                per_image_name = image_id + "." + image_type

                # 创建二级目录，秒级时间戳
                second_dir = str(int(event_time/(self.second_dir_time)))
                # 三级目录名
                belong_image_folder_name = image_id[0:2]
                # 最终目录
                second_dir_path = os.path.join(self.origin_image_folder, second_dir)

                belong_image_folder = os.path.join(second_dir_path, belong_image_folder_name)
                origin_image_path = os.path.join(belong_image_folder, per_image_name)

                with open(origin_image_path, 'rb') as fp:
                    fcntl.flock(fp, fcntl.LOCK_EX)
                    origin_image_binary = fp.read()
                    fcntl.flock(fp, fcntl.LOCK_UN)
        except Exception as e:
            self.event_image_logger.exception(e)
        return origin_image_binary

    #一次性清空所有图片
    def clear(self):
        # 还要清空图片数据
        try:
            self.write_eventdb_running = False
            self.image_queue.queue.clear()
            time.sleep(1)
            os.system("rm -rf {}".format(self.origin_image_folder))
            if not os.path.exists(self.origin_image_folder):
                os.makedirs(self.origin_image_folder)
                os.chmod(self.origin_image_folder, 0o777)
        except Exception as e:
            self.event_image_logger.exception(e)

    #清空某个二级目录，该二级目录是以时间保存的
    def clear_second_dir(self,second_dir):
        try:
            second_dir_path = os.path.join(self.origin_image_folder, second_dir)
            shutil.rmtree(second_dir_path)
        except Exception as e:
            self.event_image_logger.exception(e)


    #获取某个文件夹下的存储大小,返回结果单位为G
    def get_folder_free_size(self,dir_path=None,size_unit=''):
        free_size = None

        try:
            if not dir_path:
                dir_path = self.origin_image_folder
            result_obj = psutil.disk_usage(dir_path)
            #Byte
            free_size = result_obj.free
            if size_unit=="GB":
                free_size = free_size/(1024*1024*1024)
            elif size_unit=="MB":
                free_size = free_size/(1024*1024)
            elif size_unit == "KB":
                free_size = free_size/(1024)
        except Exception as e:
            self.event_image_logger.exception(e)

        return free_size

    #获取存储得或者是tf卡里得inode数量
    def get_inode_percent(self,dir_path=None):
        inode_percentage = 0
        try:
            if not dir_path:
                dir_path = self.origin_image_folder

            st = os.statvfs(dir_path)
            total_inode = st.f_files
            free_inode = st.f_ffree
            inode_percentage = free_inode / total_inode
        except Exception as e:
            self.event_image_logger.exception(e)

        return inode_percentage

    def list_image_folders(self):
        all_folders = []
        try:
            all_folders = os.listdir(self.origin_image_folder)
            all_folders.sort()
        except Exception as e:
            self.event_image_logger.exception(e)

        return all_folders
