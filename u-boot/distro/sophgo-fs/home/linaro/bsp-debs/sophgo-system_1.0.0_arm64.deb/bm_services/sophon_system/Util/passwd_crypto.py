from Crypto.Cipher import AES
from binascii import b2a_hex, a2b_hex

class PasswdCtypto():

    def __init__(self):
        pass


    # 如果text不足十六位的倍数用空格补充
    def add_to_16(self,text):
        if len(text.encode('utf8')) % 16:
            add = 16 - (len(text.encode('utf8')) % 16)
        else:
            add = 0
        text = text + '\0' * add
        return text


    # 加密
    def passwd_encrypt(self,text):
        key = 'bitmain123456789'.encode('utf8')
        mode = AES.MODE_CBC
        iv = b'qqqqqqqqqqqqqqqq'
        text = self.add_to_16(text)
        cryptos = AES.new(key, mode, iv)
        cipher_text = cryptos.encrypt(text)
        # 因为AES加密后的字符串不一定是ascii字符集的，输出保存可能存在问题，所以这里转为16进制字符串
        byte_text = b2a_hex(cipher_text)
        string_text = str(byte_text,encoding="utf-8")
        return string_text


    # 解密后去掉空格
    def passwd_decrypt(self,text):
        key = 'bitmain123456789'.encode('utf8')
        mode = AES.MODE_CBC
        iv = b'qqqqqqqqqqqqqqqq'
        cryptos = AES.new(key, mode, iv)
        text=bytes(text,encoding="utf-8")
        plain_text = cryptos.decrypt(a2b_hex(text))
        return bytes.decode(plain_text).rstrip('\0')


if __name__ == '__main__':
    passwd_crypto_obj = PasswdCtypto()
    a = passwd_crypto_obj.passwd_encrypt('hello')
    b = passwd_crypto_obj.passwd_decrypt(a)
    print('加密', a)
    # print(str(a,encoding="utf-8"))
    print(type(a))
    print('解密', b)