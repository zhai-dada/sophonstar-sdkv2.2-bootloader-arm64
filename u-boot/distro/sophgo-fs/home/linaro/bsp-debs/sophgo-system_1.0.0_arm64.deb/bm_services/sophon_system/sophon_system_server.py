import glv
glv.init()
glv.set_value("LOG_FILE", "/data/log/SophonSystem.log")
from flask import Flask
import subprocess
import threading
from OEMconfig import OEMConfigSingletone
import os
import logger
from upload_service import StatusUploadService

ENABLE_SYSTEM = True
ENABLE_VENDOR = True



if ENABLE_SYSTEM:
    import sys
    sys.path.append("/opt/SophonSystem")
    from system_router import get_systemapi_blueprint as get_systemapi_blueprint

custom_thread_name = False
if custom_thread_name:
	import prctl



class SystemWebserver():

    def __init__(self,  mongo_ip='localhost', output=None):
        self._logger = logger.getLogger("SystemServer")
        self.app = Flask(__name__, static_url_path='')


        self.mongo_ip = mongo_ip


        if output is None:
            server_obj = dict()
        else:
            server_obj = output
        # 构建蓝图
        self._contruct_blueprint(mongo_ip=self.mongo_ip, server_obj = server_obj)
        self._build_router()


        # 启动一个状态上报线程
        try:
            self.status_upload_service = StatusUploadService()
            self.status_upload_service.start_status_upload()
        except Exception as e:
            self._logger.exception(e)




    def _contruct_blueprint(self, mongo_ip=None, server_obj=None):


        system_blueprint, system_blueprint_config = get_systemapi_blueprint(mongo_ip=mongo_ip)

        self.app.register_blueprint(
            system_blueprint,
            url_prefix='/SophonSystem/api')

        # 统一的可配置的蓝图======
        if os.path.exists('/factory/OEMconfig.ini'):
            self.oem_config_data = OEMConfigSingletone()
            self.hole_config_prefix = self.oem_config_data.getItemConfig('PRODUCT')
        else:
            self.hole_config_prefix = "MINISERVER"
        if self.hole_config_prefix == "":
            self.hole_config_prefix = "MINISERVER"

        if self.hole_config_prefix is None:
            self.hole_config_prefix = "MINISERVER"

        self.app.register_blueprint(
            system_blueprint_config,
            url_prefix='/' + self.hole_config_prefix + '/System/api')


    def _build_router(self):
        def DeviceStatusCheck(device = None,index = None,preview_list = None,threadLock=None,action_list = None):
            url = device.get("url", None)
            print(device)
            print(index)
            print(url)
            try:
                if url is not None:
                    ip = str((url.split("//")[1]).split(":")[0])
                    shell_command = "ping -c 1 {} | grep '{}' |wc -l".format(ip, '0 received')
                    print(shell_command)
                    output = subprocess.Popen([shell_command], stdout=subprocess.PIPE,
                                              shell=True).communicate()
                    #p = subprocess.Popen(shell_command, shell=True, stdout=subprocess.PIPE)
                    #result = p.stdout.read()
                    status_id = str((output[0].strip()).decode())
                    with threadLock:
                        action_list[index] = 1
                        if status_id == "1":
                            preview_list[index]["status"] = "Offline"
                        else:
                            preview_list[index]["status"] = "Online"
                    print("action_list @ sub2:  ".format(action_list))
            except Exception as e:
                print("##################################Exception###############################")
                print(e)
                with threadLock:
                    action_list[index] = 1
                    preview_list[index]["status"] = "Exception"

    def run(self):
        self.app.run(host='0.0.0.0', port=8888, debug=False, threaded=True)


app = SystemWebserver().app

if __name__ == '__main__':
    gate_webserver = SystemWebserver()
    gate_webserver.run()
