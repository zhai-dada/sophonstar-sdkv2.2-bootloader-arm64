from pathlib import Path
configFolder = '/data/config/'

#configFolder = ''
from non_volatile_config import NonVolatileConfigParser
import _thread
import traceback
import sys
import os
import json


class myconf(NonVolatileConfigParser):
    def __init__(self,defaults=None):
        super().__init__()
    def optionxform(self, optionstr):
        return optionstr

class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]


class ConfigDataSingletone(metaclass=Singleton):
    def __init__(self):

        try:
            if not os.path.exists(configFolder):
                os.makedirs(configFolder)
                os.chmod(configFolder, 0o777)
        except Exception as e:
            print(str(e))


        self.configFile = configFolder + 'system_config.ini'
        self.configData = {

            'MONITOR_ADDRESS_LIST': "",
            'REPORT_PERIOD': 20,
            'DEV_SNO': "",
        }
        # 当配置文件不存在时候创建一个默认得配置文件
        try:
            if not os.path.exists(self.configFile):
                self.create_configs(self.configData)
        except Exception as e:
            print(str(e))

        self.configTime = self.ConfigTime(self.configFile)
        self.lock = _thread.allocate_lock()
        self.fileupdatetime = os.path.getmtime(self.configFile)
        self.loadConfig(self.configFile)

    def ConfigTime(self, configFile):
        if Path(configFile).is_file():
            # return os.path.getmtime(configFile)
            return 0
        else:
            return 0

    def setConfig(self, key, value):
        with self.lock:

            if key == 'MONITOR_ADDRESS_LIST':
                self.configData[key] = str(value)
                self.setConfigs('BASE', key, value)
            elif key == 'REPORT_PERIOD':
                self.configData[key] = int(value)
                self.setConfigs('BASE', key, value)
            elif key == 'DEV_SNO':
                self.configData[key] = str(value)
                self.setConfigs('BASE', key, value)
            else:
                return False
                # print('######ConfigDataSingletone setconfig with bad key#########')

            return True

    def getItemConfig(self, key):
        fileupdatetime = os.path.getmtime(self.configFile)
        if self.fileupdatetime != fileupdatetime:
            self.loadConfig(self.configFile)
            self.fileupdatetime = fileupdatetime
        if key in self.configData:
            return self.configData[key]
        else:
            print('------getconfig with bad key{}----------'.format(key))
            return None

    def create_configs(self,configs_dict):
        try:
            config = myconf()
            group="BASE"
            config.add_section(group)
            for key,value in configs_dict.items():
                config.set(group, key, str(value))
            with open(self.configFile, 'w') as f:
                config.write(f)
        except Exception as e:
            print(str(e))

    def setConfigs(self, group, key, value):
        # print("###########setConfigs#######")
        if not Path(self.configFile).exists():
            print("[ERROR] config file is not exist")
            return
        config = myconf()
        if not config.read(self.configFile):
            print("[ERROR] READ CONFING FILE FAILED")
            return

        config.set(group, key, str(value))
        with open(self.configFile, 'w') as f:
            config.write(f)
        self.fileupdatetime = os.path.getmtime(self.configFile)


    def getConfig(self):
        with self.lock:
            return self.configData.copy()

    def loadConfig(self, configFile):
        """
            Get config from configfile
        """
        print("--------System loadConfig-----------")
        print(configFile)
        if not Path(configFile).exists():
            print("[ERROR] config file is not exist")
            return
        config = myconf()
        if not config.read(configFile):
            print("[ERROR] READ CONFING FILE FAILED")
            return
        try:


            if 'MONITOR_ADDRESS_LIST' in config["BASE"]:
                self.configData['MONITOR_ADDRESS_LIST'] = str(config['BASE']['MONITOR_ADDRESS_LIST'])

            if 'REPORT_PERIOD' in config["BASE"]:
                self.configData['REPORT_PERIOD'] = int(config['BASE']['REPORT_PERIOD'])

            if 'DEV_SNO' in config["BASE"]:
                self.configData['DEV_SNO'] = str(config['BASE']['DEV_SNO'])

        except KeyError as err:
            print("{} parameter is not in config.ini".format(err.args))
            raise KeyError("{} parameter is not in config.ini\nPlease check the config.ini".format(err.args))
        except ValueError as err:
            traceback.print_exc()
            print("Please Check the value type in config.ini is right ? int or string or float?")
            sys.exit(1)


if __name__ == '__main__':
    config1 = ConfigDataSingletone()
    workmode = config1.getItemConfig("WORK_MODE")
