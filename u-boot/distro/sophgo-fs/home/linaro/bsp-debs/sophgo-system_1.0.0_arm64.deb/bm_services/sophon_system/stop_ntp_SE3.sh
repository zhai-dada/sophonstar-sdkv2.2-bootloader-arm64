#!/bin/bash
mount -o remount,rw /
systemctl stop systemd-timesyncd
systemctl disable systemd-timesyncd
mount -o remount,ro /
