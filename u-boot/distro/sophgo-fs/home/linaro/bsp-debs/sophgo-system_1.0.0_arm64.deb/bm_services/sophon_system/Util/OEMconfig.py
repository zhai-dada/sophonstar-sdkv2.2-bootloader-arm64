# -*- coding: utf-8 -*-
from pathlib import Path

configFolder = '/factory/'

# configFolder = ''
from non_volatile_config import NonVolatileConfigParser
import _thread
import traceback
import sys
import json
import os


class myconf(NonVolatileConfigParser):
    def __init__(self, defaults=None):
        super().__init__()

    def optionxform(self, optionstr):
        return optionstr


class SingletonOEM(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(SingletonOEM, cls).__call__(*args, **kwargs)
        return cls._instances[cls]


class OEMConfigSingletone(metaclass=SingletonOEM):
    def __init__(self):
        self.configFile = configFolder + 'OEMconfig.ini'
        self.configTime = self.ConfigTime(self.configFile)
        self.lock = _thread.allocate_lock()
        self.configData = {
            'PRODUCT': 'MINISERVER'
        }
        self.loadConfig(self.configFile)

    def ConfigTime(self, configFile):
        if Path(configFile).is_file():
            # return os.path.getmtime(configFile)
            return 0
        else:
            return 0

    def setConfig(self, key, value):
        with self.lock:

            if key == "PRODUCT":
                self.configData[key] = str(value)
                self.setConfigs('BASE', key, value)
            else:
                print('######OEMconfig setconfig with bad key#########')

    def getItemConfig(self, key):
        if key in self.configData:
            return self.configData[key]
        else:
            print('######OEMconfig getconfig with bad key#########')
            return None

    def setConfigs(self, group, key, value):
        print("###########setConfigs#######")
        if not Path(self.configFile).exists():
            print("[ERROR] config file is not exist")
            return
        config = myconf()
        if not config.read(self.configFile):
            print("[ERROR] READ CONFING FILE FAILED")
            return
        # try:
        print(group)
        print(key)
        print(value)
        print(config.sections())
        print(config.items(group))
        config.set(group, key, str(value))
        with open(self.configFile, 'w') as f:
            config.write(f)
            # os.system('sync')
            # f = open(self.configFile,'w')
            # config.write(f)
            # f.close()
            # except Exception as e:
            # print("setconfig faild.{}.{}".format(group,key))

    def getConfig(self):
        with self.lock:
            return self.configData.copy()

    def loadConfig(self, configFile):
        """
            Get config from configfile
        """
        print("#############loadConfig########")
        print(configFile)
        if not Path(configFile).exists():
            print("[ERROR] config file is not exist")
            return
        config = myconf()
        if not config.read(configFile):
            print("[ERROR] READ CONFING FILE FAILED")
            return
        try:

            if 'PRODUCT' in config["BASE"]:
                self.configData['PRODUCT'] = str(config['BASE']['PRODUCT'])
            if 'SN' in config["BASE"]:
                self.configData['SN'] = str(config['BASE']['SN'])
            if 'MAC' in config["BASE"]:
                self.configData['MAC'] = str(config['BASE']['MAC'])
            if 'ALGORITHM' in config["BASE"]:
                self.configData['ALGORITHM'] = str(config['BASE']['ALGORITHM'])
            if 'RESERVE_STRING_0' in config["BASE"]:
                self.configData['RESERVE_STRING_0'] = str(config['BASE']['RESERVE_STRING_0'])
            if 'BOARD_TYPE' in config["BASE"]:
                self.configData['BOARD_TYPE'] = str(config['BASE']['BOARD_TYPE'])
            if 'BOM' in config["BASE"]:
                self.configData['BOM'] = str(config['BASE']['BOM'])
            if 'MODULE_TYPE' in config["BASE"]:
                self.configData['MODULE_TYPE'] = str(config['BASE']['MODULE_TYPE'])
            if 'EX_MODULE_TYPE' in config["BASE"]:
                self.configData['EX_MODULE_TYPE'] = str(config['BASE']['EX_MODULE_TYPE'])
            if 'VENDOR' in config["BASE"]:
                self.configData['VENDOR'] = str(config['BASE']['VENDOR'])
            if 'DATE_PRODUCTION' in config["BASE"]:
                self.configData['DATE_PRODUCTION'] = str(config['BASE']['DATE_PRODUCTION'])

            if 'RESERVE_STRING_2' in config["BASE"]:
                self.configData['RESERVE_STRING_2'] = str(config['BASE']['RESERVE_STRING_2'])
            if 'RESERVE_STRING_3' in config["BASE"]:
                self.configData['RESERVE_STRING_3'] = str(config['BASE']['RESERVE_STRING_3'])
            if 'RESERVE_STRING_4' in config["BASE"]:
                self.configData['RESERVE_STRING_4'] = str(config['BASE']['RESERVE_STRING_4'])
            if 'RESERVE_STRING_5' in config["BASE"]:
                self.configData['RESERVE_STRING_5'] = str(config['BASE']['RESERVE_STRING_5'])
            if 'RESERVE_STRING_6' in config["BASE"]:
                self.configData['RESERVE_STRING_6'] = str(config['BASE']['RESERVE_STRING_6'])

        except KeyError as err:
            print("{} parameter is not in config.ini".format(err.args))
            raise KeyError("{} parameter is not in config.ini\nPlease check the config.ini".format(err.args))
        except ValueError as err:
            traceback.print_exc()
            print("Please Check the value type in config.ini is right ? int or string or float?")
            sys.exit(1)
