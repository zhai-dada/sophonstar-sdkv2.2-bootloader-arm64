import glv
glv.init()
glv.set_value("LOG_FILE", "/data/log/ShellDaemon.log")
import subprocess
import socket
import logger
from socket import error as SocketError
import errno

servce=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
servce.bind(("localhost",9090))
servce.listen(60)
logger = logger.getLogger("ShellDaemon")
logger.info("start shell socket lisening server")

while True:
    conn,addr=servce.accept()
    while True:
        try:
            data=conn.recv(1024)
            if (len(data) > 2) :
                cmd = str(data, encoding = "utf-8")
                logger.info('socket server exec : {}'.format(cmd))

                err,result=subprocess.getstatusoutput(cmd)
                if err != 0:
                    conn.send(bytes("100", encoding = "utf8"))
                else:
                    if (len(result) > 0 and len(result) < 1024):
                        conn.send(bytes(result, encoding = "utf8"))
                    else:
                        conn.send(bytes("0", encoding = "utf8"))
            else:
                conn.close()
                break
        except SocketError as e:
            logger.info('socket error is :  {}'.format(e.errno))
            if e.errno != errno.ECONNRESET:
                logger.info('socket error is :  {}'.format(e.errno))
            pass
logger.info("out accept")

