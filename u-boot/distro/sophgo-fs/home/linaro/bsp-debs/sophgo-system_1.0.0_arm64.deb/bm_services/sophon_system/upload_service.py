import logger
import threading
import time
import requests
from system_router import SystemFan,get_pretty_result
from system_config import ConfigDataSingletone
import psutil
from system_factory import SystemFunction
system_fun = SystemFunction()

_logger = logger.getLogger("SystemServer")



class StatusUploadService(object):
    def __init__(self):
        self.get_system_info_obj = GetSystemInfo()
        self.configdata=ConfigDataSingletone()

    def start_status_upload(self):
        status_upload_thread = threading.Thread(target=self.status_upload_func)
        status_upload_thread.start()

    def status_upload_func(self):

        while 1:
            try:
                report_period = self.configdata.getItemConfig("REPORT_PERIOD")
                dev_sno = self.configdata.getItemConfig("DEV_SNO")
                monitor_address_string = self.configdata.getItemConfig("MONITOR_ADDRESS_LIST")
                monitor_address_list = monitor_address_string.split(",")
                if "" in monitor_address_list:
                    monitor_address_list.remove("")
                if monitor_address_list:
                    for per_upload_status_url in monitor_address_list:
                        try:
                            gateway_ip, gateway_mac = self.get_system_info_obj.get_ip_and_mac()
                            gateway_name = self.get_system_info_obj.get_hostname()
                            gateway_sn = self.get_system_info_obj.get_gateway_sn()
                            fan_speed=self.get_system_info_obj.get_fan_speed_string_func()
                            uptime = self.get_system_info_obj.get_uptime()
                            tpu_info = self.get_system_info_obj.get_tpu_info()

                            core_temperature, board_temperature = self.get_system_info_obj.get_temperature()
                            gateway_ext_data={}
                            sw_version,mw_version,sdk_version = self.get_system_info_obj.get_version()
                            gateway_ext_data['sw_version'] = sw_version
                            gateway_ext_data['sdk_version'] = sdk_version
                            gateway_ext_data['gateway_mac'] = gateway_mac
                            gateway_ext_data['cpu_info'] = self.get_system_info_obj.get_cpu_info()
                            gateway_ext_data['memory_info'] = self.get_system_info_obj.get_memory_info()
                            gateway_ext_data['disk_info'] = self.get_system_info_obj.get_disk_info()
                            gateway_ext_data['external_hard_drives_info'] = self.get_system_info_obj.get_external_hard_drives_info()
                            gateway_ext_data['temperature'] = core_temperature
                            gateway_ext_data['board_temperature'] = board_temperature
                            gateway_ext_data['nnsdk_version'] = mw_version
                            gateway_ext_data['fan_speed'] = fan_speed
                            gateway_ext_data['uptime'] = uptime
                            gateway_ext_data['tpu_info'] = tpu_info
                            #获取上报信息
                            send_data = {
                                "gateway_ip":gateway_ip,
                                "gateway_name":gateway_name,
                                "gateway_status":"online",
                                "gateway_sn":gateway_sn,
                                "gateway_port":None,
                                "dev_sno":dev_sno,
                                "gateway_ext_data":gateway_ext_data
                            }

                            _logger.info("===========status_upload send_data= {}".format(send_data))

                            # 发送到远程平台
                            server_res = requests.post(url=per_upload_status_url, json=send_data, timeout=30)
                            if server_res.status_code == 200:
                                _logger.info("[status_upload]===============status_upload info send success ================")
                            else:
                                _logger.info("[status_upload]========status_upload send failed status_code {} ========".format(server_res.status_code))
                        except Exception as e:
                            _logger.exception(e)
                time.sleep(report_period)
            except Exception as e:
                _logger.exception(e)

            time.sleep(5)

class GetSystemInfo():
    def __init__(self):
        _logger = logger.getLogger("SystemServer")


    def get_temperature(self):
        core_temperature = 0
        board_temperature = 0

        try:
            board_temperature, core_temperature = system_fun.getSystemTemperature()
        except Exception as e:
            _logger.exception(e)

        return core_temperature,board_temperature

    def get_disk_info(self):
        disk_info = {}
        headers = {'Content-Type': 'application/json'}
        try:
            disk_info = system_fun.getSystemDisk()
        except Exception as e:
            _logger.exception(e)
        return disk_info


    def get_memory_info(self):
        memory_info = {}
        try:
            memory_info = system_fun.getSystemMemory()

        except Exception as e:
            _logger.exception(e)


        return memory_info


    def get_cpu_info(self):
        cpu_info = {}
        headers = {'Content-Type': 'application/json'}
        try:
            cpu_info = system_fun.getCpuData()

        except Exception as e:
            _logger.exception(e)

        return cpu_info


    def get_ip_and_mac(self):
        ip = "192.168.1.180"
        mac = "0.0.0.0"

        try:
            ret_data = system_fun.getIP()

            if ret_data is not None:
                ip1 = ret_data[0].get('ip', "192.168.1.180")
                mac = ret_data[0].get('mac', "0.0.0.0")

                ip2= ret_data[1].get('ip', "192.168.1.180")
                ip = ip1 + " " + ip2
        except Exception as e:
            _logger.exception(e)

        return ip, mac

    def get_hostname(self):
        hostname = {}
        headers = {'Content-Type': 'application/json'}
        try:
            response_data = system_fun.getHostName()
            hostname = response_data['hostname']
        except Exception as e:
            _logger.exception(e)
        return hostname

    def get_gateway_sn(self):
        gateway_sn = None

        try:
            gateway_sn = system_fun.getDeviceSN()

        except Exception as e:
            _logger.exception(e)

        return gateway_sn

    def get_version(self):
        sw_version = None
        mw_version = None
        sdk_version = None
        FilePath = '/opt/data/buildinfo.txt'
        try:
            with open(FilePath, 'r') as f:
                txt = f.read()
                print(txt)
                str_list = txt.splitlines()
                sw_version = str_list[1].split(':')[1]
                mw_version = str_list[2].split(':')[1]
                sdk_version = str_list[3].split(':')[1]
        except Exception as e:
            print('[getSWVersion]http fail')
            _logger.exception(e)
        return sw_version,mw_version,sdk_version

    def get_external_hard_drives_info(self):
        result = {}
        result['external_hard_state'] = "0"
        result['external_hard_total_disk'] = "0G"
        result['external_hard_used_disk'] = "0G"
        result['external_hard_free_disk'] = "0G"
        result['external_hard_disk_rate'] = 0.0
        headers = {'Content-Type': 'application/json'}
        try:
            response_data = system_fun.getExternalDisk()
        except Exception as e:
            _logger.exception(e)

        return result

    def get_fan_speed_string_func(self):
        fan_speed = "0r/min"

        try:
            fan_rate = system_fun.getSystemFan()
            fan_speed = str(fan_rate) + "r/min"
        except Exception as e:
            _logger.exception(e)
        return fan_speed

    def get_uptime(self):
        uptime = "0minutes"
        headers = {'Content-Type': 'application/json'}
        try:
            response_data = system_fun.getUptime()
            uptime = response_data['uptime']
        except Exception as e:
            _logger.exception(e)
        return uptime

    def get_tpu_info(self):
        tpu_info = {}

        try:
            tpu_info = system_fun.getTpuData()
        except Exception as e:
            _logger.exception(e)
        return tpu_info
