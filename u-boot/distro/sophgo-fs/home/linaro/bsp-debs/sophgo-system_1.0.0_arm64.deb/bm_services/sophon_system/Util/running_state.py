def run_in_docker() -> bool:
    state = False
    with open("/proc/1/cpuset", "r") as fd:
        line = fd.read()
        if "docker" in line or "pod" in line:
            state = True
    return state
