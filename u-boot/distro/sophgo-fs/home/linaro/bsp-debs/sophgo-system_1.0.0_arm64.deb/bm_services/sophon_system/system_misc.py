import base64
import threading

import flask
import urllib.request
from http import HTTPStatus
from enum import IntEnum
from running_state import run_in_docker
import subprocess
import netifaces
import os
import logger

_logger = logger.getLogger("SystemServer")

class ErrorResponseType(IntEnum):
    #成功的返回
    SUCCESS = 20091

    # 400 BAD_REQUEST
    URL_INVAL = 40090
    PARAM_ERROR = 40091
    REPORTED_PEROID_INVAL = 40092


    # 404 NOT_FOUND,比如group name没有的时候
    NOT_FOUND = 40491

    #415 请求类型错误
    CONTENT_TYPE_ERROR = 41591

    # 500 NOT_IMPLEMENTED
    SERVER_ERROR = 50091

    #执行脚本错误
    EXCELL_SCRIPTS_ERROR=400010

    NOT_FOUND_4G_MODULE = 400011
    RESTART_DOCKER_ERROR = 400012
    NOT_FOUND_FILE = 400013

    MISS_MD5_INFORMATION = 400014
    NO_FILE_UPLOADED = 400015
    UPLOAD_FILE_NOT_VALID = 400016
    CALL_UPDATE_FUNCTION_NO_REPEAT = 400017
    FILE_IS_BROKEN = 400018
    SAVE_FILE_ERROR = 400019
    CHECK_MD5_ERROR = 400020

def make_response(data=None, error=None, status_code=HTTPStatus.OK):
    ret = {}
    if data is None and error is None:
        raise('at least one of data or error')
    if data is not None:
        ret['data'] = data
    if error is not None:
        ret['error'] = error
    return flask.make_response(flask.jsonify(ret), status_code)


def make_success_response():
    return make_response('ok')


def make_error_response(error_type, message="", chinese_message=""):

    status_code = HTTPStatus(int(str(error_type.value)[:3]))
    if error_type == ErrorResponseType.URL_INVAL:
        message = 'Invalid URL address'
    elif error_type == ErrorResponseType.REPORTED_PEROID_INVAL:
        message = "Invalid reported_peroid"
    elif error_type == ErrorResponseType.SERVER_ERROR:
        message = "server process error"
        chinese_message = "服务器进程出错"
    elif error_type == ErrorResponseType.EXCELL_SCRIPTS_ERROR:
        message = "execShell scripts error"
        chinese_message = "执行脚本内部错误"
    elif error_type == ErrorResponseType.NOT_FOUND_FILE:
        message = "not found file"
        chinese_message = "未找到文件"
    elif error_type == ErrorResponseType.NOT_FOUND_4G_MODULE:
        message = "not found 4G module"
        chinese_message = "未检测到4G模块"
    elif error_type == ErrorResponseType.MISS_MD5_INFORMATION:
        message = "miss md5 information"
        chinese_message = "缺少md5信息"
    elif error_type == ErrorResponseType.NO_FILE_UPLOADED:
        message = "no file uploaded"
        chinese_message = "无文件上传"
    elif error_type == ErrorResponseType.UPLOAD_FILE_NOT_VALID:
        message = "upload file not valid"
        chinese_message = "上传文件无效"
    elif error_type == ErrorResponseType.CALL_UPDATE_FUNCTION_NO_REPEAT:
        message = "call update function no repeat"
        chinese_message = "内部升级接口调用失败"
    elif error_type == ErrorResponseType.FILE_IS_BROKEN:
        message = "file is broken"
        chinese_message = "文件可能损坏"
    elif error_type == ErrorResponseType.SAVE_FILE_ERROR:
        message = "save file error,maybe no space left"
        chinese_message = "文件保存失败，剩余空间可能不足"
    elif error_type == ErrorResponseType.CHECK_MD5_ERROR:
        message = "check md5 error"
        chinese_message = "md5值不一致"
    else:
        message = str(message) if message else ''

    return make_response(
        error={
            'code': error_type.value,
            'status': error_type.name,
            'message': str(message),
            'chinese_message':str(chinese_message)
        },
        status_code=status_code
    )



def make_old_response(data=None, error=None, status_code=HTTPStatus.OK):
    if data is None and error is None:
        raise('at least one of data or error')
    if data is not None:
        ret = data
    if error is not None:
        ret = error
    return flask.make_response(flask.jsonify(ret), status_code)


def make_response_image_jpeg(image_binary):
    response = flask.make_response(image_binary)
    response.headers.set('Content-Type', 'image/jpeg')
    return response

def response_no_image(note=''):
    return make_response(
        error={ 'message': 'empty or broken image' + ((': ' + note) if note else '') },
        status_code=HTTPStatus.BAD_REQUEST
    )

def response_unsupport_content_type(note=''):
    return make_response(
        error={ 'message': 'unsupported content-type' + ((': ' + note) if note else '') },
        status_code=HTTPStatus.BAD_REQUEST
    )

def response_not_found(note=''):
    return make_response(
        error={ 'message': 'not found' + ((': ' + note) if note else '') },
        status_code=HTTPStatus.NOT_FOUND
    )

def response_bad_request(note=''):
    return make_response(
        error={ 'message': 'bad request' + ((': ' + note) if note else '') },
        status_code=HTTPStatus.BAD_REQUEST
    )

def url_to_binary(url):
    with urllib.request.urlopen(url) as response:
        binary = response.read()
    return binary

def base64str_to_binary(image_base64str):
    image_base64str = image_base64str.split(',')[-1]
    binary = base64.b64decode(image_base64str)
    return binary


def get_pretty_result(data):
    #对传进来的数据进行转化
    result = str(data) + "M"
    if data > 1000:
        data = round((data / 1024.0),2)
        result = str(data)+ "G"
    else:
        result = str(data)+"M"
    return result

def get_ip_implement(device):
    try:
        routingGateway = ""
        if(netifaces.AF_INET in netifaces.ifaddresses(device)):
            if(netifaces.AF_INET in netifaces.gateways()):
                gw_list = netifaces.gateways()[netifaces.AF_INET]
                for gw in gw_list:
                    print(gw)
                    if(gw[1] == device):
                        routingGateway = gw[0]

        status = os.path.exists('/etc/network/interfaces.d/' + device)
        res = dict()
        res['device'] = device
        if status:
            IP_info = list()
            with open('/etc/network/interfaces.d/' + device, 'r') as f:
                for data in f.readlines():
                    IP_info.append(data.strip('\n'))
            ip_idx = IP_info[2].find('address')  # find ip location
            res['ip'] = IP_info[2][ip_idx+8:]

            netmask_idx = IP_info[3].find('netmask')  # find netmask location
            res['netmask'] = IP_info[3][netmask_idx+8:]

            if device == "eth1":
                dns_idx = IP_info[4].find('dns-nameservers')  # find dns location
                res['dns'] = IP_info[4][dns_idx+16:]
            if device == "eth0":
                gw_idx = IP_info[4].find('gateway')  # find dns location
                res['gateway'] = IP_info[4][gw_idx+8:]
                dns_idx = IP_info[5].find('dns-nameservers')  # find dns location
                res['dns'] = IP_info[5][dns_idx+16:]

            res['status'] = 'static'
        else:
            res['status'] = 'dynamic'
            res['gateway'] = routingGateway
            res['dns'] = ""
            if(netifaces.AF_INET in netifaces.ifaddresses(device)):
                res['ip'] = netifaces.ifaddresses(device)[netifaces.AF_INET][0]['addr']
                res['netmask'] = netifaces.ifaddresses(device)[netifaces.AF_INET][0]['netmask']
            else:
                res['ip'] = ""
                res['netmask'] = ""

    except OSError:
        print("get ip error!")

    return res

def fun_restart_timer():
    print('#####reboot####')
    execShell("reboot")

def restart_service():
    print('#####delya reboot####')
    timer = threading.Timer(10, fun_restart_timer)
    timer.start()



def to_bool(val):
    if isinstance(val, bool):
        return val
    val = val.lower()

    if val in ('y', 'yes', 't', 'True', 'TRUE','true', 'on', '1'):
        return True
    elif val in ('n', 'no', 'f', 'false', 'off', '0'):
        return False
    elif val == 1:
        return True
    elif val == 0:
        return False
    else:
        raise BooleanArgumentError("invalid boolean value %r" % (val,))
def execShell(cmd):
    print(cmd)
    err,result = subprocess.getstatusoutput(cmd)
    return err,result

def get_product():
    # if run_in_docker():
    #     product = "docker"
    # else:
    device_file = '/factory/OEMconfig.ini'
    product = ""
    try:
        with open(device_file) as f:
            line = f.readlines()
            for textLine in line:
                if textLine.find('PRODUCT = ')>=0:
                    product = textLine.split('=')[1].strip('\n').strip()
                    break

    except Exception as e:
        _logger.exception(e)
    return product
