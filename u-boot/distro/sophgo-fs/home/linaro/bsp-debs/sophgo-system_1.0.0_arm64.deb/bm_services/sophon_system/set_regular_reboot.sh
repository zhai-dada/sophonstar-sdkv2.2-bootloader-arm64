#!/bin/bash


#clear 
#sed -i "/CUSTOMER CMD reboot FOR BITMAIN/d" crontab
num=$#
if [ $# -lt 2 ] ; then
    echo "./set_regular_reboot.sh hour daylist"
    echo "eg: ./set_regular_reboot.sh 13 1 2 3 4 5 6 7"
    exit -1
fi

hour=$1
str=""
sed -i "/CUSTOMER CMD reboot FOR BITMAIN/d" /etc/crontab
for i in $(seq 2 $num)
do
    day[$i]=${!i}
    if [ $i -eq $num ] ; then
        str="$str${!i}"
    else
        str="$str${!i},"
    fi
done
echo $str
echo "restart time is $hour"
echo "restart day is ${day[*]}"

sed -i "\$a\00 ${hour}    * * ${str}   root     echo 'CUSTOMER CMD reboot FOR BITMAIN!!!'; reboot" /etc/crontab 

sudo systemctl restart cron


