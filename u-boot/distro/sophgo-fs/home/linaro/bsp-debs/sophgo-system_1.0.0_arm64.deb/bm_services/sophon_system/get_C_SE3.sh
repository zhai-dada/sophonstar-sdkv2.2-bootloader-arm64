#!/bin/bash

i2cset -y 2 0x4c 0xb 0x7f
i2cset -y 2 0x4c 0xc 0xc0
i2cset -y 2 0x4c 0xd 0x7f
i2cset -y 2 0x4c 0xe 0xc0

local=$(($(i2cget -y 2 0x4c 0x0)))
remote=$(($(i2cget -y 2 0x4c 0x1)))
if [ $local -ge 128 ]; then
  local=$[$local-256]
fi
if [ $remote -ge 128 ]; then
  remote=$[$remote-256]
fi
echo "board temperature: $local'C; die temperature: $remote'C"
