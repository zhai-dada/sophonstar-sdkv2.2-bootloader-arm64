#!/usr/bin/expect

set timeout 5
set CoreBoardIp [lindex $argv 0]
set UserName [lindex $argv 1]
set Password [lindex $argv 2]

spawn ssh $UserName@$CoreBoardIp

expect {
	"yes/no/?" {
		send "yes\r"
		expect "password:"
		send "$Password\r"
	}
	"password:" {
		send "$Password\r"
	}
}

expect {
	"Permission denied" {send_user "Password is wrong"}
	"*login*" {send_user "Password is correct"  }
	"Debian*" {send_user "Password is correct"  }
	"Welcome to Ubuntu 20.04 LTS" {send_user "Password is correct"  }
	default {send_user "Password is wrong"}
	}


