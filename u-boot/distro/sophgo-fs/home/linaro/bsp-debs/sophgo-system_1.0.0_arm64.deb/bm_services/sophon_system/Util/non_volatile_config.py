from configparser import ConfigParser
import hashlib
import json
import os
import logger
import fcntl
import time
SECTION_MD5 = 'CONFIG_PARSER'

class NonVolatileConfigParser(ConfigParser):
    """
    受限与多进程读写的非原子性，以及linux操作系统的文件缓存机制，读取配置文件时有一定的机率内容为空。主要分为三种不同情况，
    分别应对为下。
    A: 当两个以上的进程同时写入同一配置文件时，因为写入操作的非原子性，会造成文件内容不同步。这个靠引入文件锁来解决，可以保证
    文件同一时刻只会被单一进程写入。
    B: 因为linux文件系统的分级缓存机制，即使使用os.fsync强制写入操作同步到磁盘设备，也无法保证其它进程在相同时刻读取的文件内容是
    正确的。可以很容易模拟出这个问题。理论上可以通过directio的方式跳过文件缓存，直接写磁盘来规避。但configparser的实际读取包
    在python库文件中，直接改对系统影响较大。所以，对于此case，如果发现为空，采用多次重复读取的方式改善。
    C: 在配置文件写入时，如果系统突然掉电，理论上重启后配置文件是会为空（因为config在写入清会清空文件）。这种情况可以通过如下
    使用AB备份机制，确保config文件会被完整写入至硬盘才生效。
    如果未被完整写入，则下次读取文件时，会仅会读取旧版本配置文件，新版本不会生效。
    目的是避免configParser write()函数在某些写入情况下造成的空配置文件问题

    以上详细说明，请参见confluence: https://info.bitmain.vip:8443/pages/viewpage.action?pageId=81456188

    实现方式：
        在每次写入配置文件时，会为当前配置文件的所有内容生成hash校验，并且将校验值写入到 [CONFIG_PARSER] section中。
        然后执行硬盘写入工作，在写入完成后，会将完整的配置文件拷贝一份到备份文件（原始配置文件+'.backup'）中。
        在读取配置文件时，会校验 hash 值。如果当前文件的内容与 hash 值不相符合，则会尝试从备份文件中读取内容。

    注意：
        1. 如何手动更改配置文件？
        手动更改配置文件时，可以临时将 enable_hash_verification 设置为 false，则会强制读取配置文件并忽略 MD5 校验。系统
        系统会自动将 enable_hash_verification 置位为 true，以便下一次开启校验机制。
        2. 如果是手工生成的初始化配置文件。请确保配置文件中至少有以下配置：
        [CONFIG_PARSER]
        enable_hash_verification = false

    """

    def __init__(self):
        super().__init__()
        self._logger = logger.getLogger("CONFIG_PARSER")

    def read(self, file):
        """
        从当前配置文件或者备份配置文件中读取正确的配置，并根据hash值做校验。
        如果两个文件均校验失败，则返回 None
        :param file:
        :return:
        """
        self._logger.debug("INI read: %s" %(file))

        #此处是为了***改善***文件在多进程快速读取的情况下，文件读取为空的情况。
        cf = super().read(file)
        max_retry = 0
        while(len(self.sections()) == 0):
            time.sleep(0.1)
            cf = super().read(file)
            max_retry += 1
            self._logger.debug("%s blank file reading retry: %d" %(file, max_retry))
            if max_retry>10:
                break

        real_md5 = self.__get_MD5()

        # case 1: MD5 值相符合，直接返回 cf
        if self.has_section(SECTION_MD5):
            self._logger.debug("%s conf read case#1" %file)
            cur_md5 = self.get(SECTION_MD5, 'MD5')
            if cur_md5 == real_md5:
                return cf
            elif self.get(SECTION_MD5, 'enable_hash_verification') == 'false':
                self.set(SECTION_MD5, 'enable_hash_verification', 'true')
                with open(file, 'w') as f:
                    try:
                        fcntl.flock(f, fcntl.LOCK_EX)
                        self.write(f)
                    except OSError:
                        self._logger.warn("%s write was locked!" %file)
                return cf

        # case 2: 没有 MD5 section, 并且文件为非空，则认为是旧版本
        # 这时会将旧文件升级为带 HASH 的新格式，并生成备份文件
        # 文件格式升级完成后，返回新的 cf
        elif len(self.sections()) != 0:
            self._logger.debug("%s conf read case#2" % file)
            self.add_section(SECTION_MD5)
            self.set(SECTION_MD5, 'MD5', real_md5)
            self.set(SECTION_MD5, 'enable_hash_verification', 'true')
            with open(file, 'w') as f:
                try:
                    fcntl.flock(f, fcntl.LOCK_EX)
                    self.write(f)
                except OSError:
                    self._logger.warn("%s write was locked!" %file)

            # 首先移除掉已读进来的配置
            for section in self.sections():
                self.remove_section(section)
            # 重新读取备份配置文件
            cf = super().read(file)
            return cf

        # case 3: MD5 值不相符合， 或者文件为空
        # 则从配置文件中读取，返回 cf
        self._logger.warn("%s conf read case#3" %file)
        backup = file + '.backup'
        #首先移除掉已读进来的配置
        for section in self.sections():
            self.remove_section(section)
        #重新读取备份配置文件
        cf = super().read(backup)
        #再次比较md5文件
        real_md5 = self.__get_MD5()
        if self.has_section(SECTION_MD5):
            cur_md5 = self.get(SECTION_MD5, 'MD5')
            if cur_md5 == real_md5:
                # 备份文件的MD5是正确的，将会把原始配置文件覆盖掉
                with open(backup, 'r') as fin:
                    with open(file, 'w') as fout:
                        try:
                            fcntl.flock(fin, fcntl.LOCK_EX)
                            fcntl.flock(fout, fcntl.LOCK_EX)
                            fout.write(fin.read())
                            fout.flush()
                            os.fsync(fout.fileno())  # 确保文件从文件系统写入至硬盘
                        except OSError:
                            self._logger.warn("%s write was locked!" % file)

                return cf

        return None


    def write(self, fp):
        """
        将当前配置信息同时写入到配置文件和备份配置文件，并生成相应的hash值
        :param fp:
        :return:
        """
        md5 = self.__get_MD5()
        if not self.has_section(SECTION_MD5):
            self.add_section(SECTION_MD5)
        self.set(SECTION_MD5, 'MD5', md5)
        self.set(SECTION_MD5, 'enable_hash_verification', 'true')
        try:
            fcntl.flock(fp, fcntl.LOCK_EX)
            super().write(fp)
            fp.flush()
            os.fsync(fp.fileno())  # 确保文件从文件系统写入至硬盘
        except OSError:
            self._logger.warn("%s write was locked!" %fp.name)

        # AB backup，将完整文件内容复制到backup文件中
        name = fp.name
        backup = name+'.backup'

        # fp已经处理写模式，所以此处提前关闭
        fp.close()
        with open(name, 'r') as fin:
            with open(backup,'w') as fout:
                try:
                    fcntl.flock(fin, fcntl.LOCK_EX)
                    fcntl.flock(fout, fcntl.LOCK_EX)
                    fout.write(fin.read())
                except OSError:
                    self._logger.warn("%s write was locked!" % fp.name)

    def __get_MD5(self):
        md5 = hashlib.md5()
        for section in self.sections():
            #将configparser_md5 section 设置为保留section, 不计入MD5 hash运算中
            if section == SECTION_MD5:
                break;
            data = self.items(section)
            md5.update(json.dumps(data).encode('utf-8'))
        return md5.hexdigest()

def main():
    name = 'FRSYS_config.ini'

    cf = NonVolatileConfigParser()

    my_config = cf.read(name)

    print(cf.get('BASE', 'WORK_MODE'))
    print(cf.get('USER', 'name'))

    cf.set('USER', 'name', 'jimmy2')

    with open(name, 'w') as f:
        cf.write(f)

if __name__ == '__main__':
    main()