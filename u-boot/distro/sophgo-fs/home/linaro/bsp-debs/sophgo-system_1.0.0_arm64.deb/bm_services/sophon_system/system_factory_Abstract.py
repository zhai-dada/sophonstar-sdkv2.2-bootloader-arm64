import abc

class AbstractSystemFactory(object):
    __metaclass__=abc.ABCMeta
    @abc.abstractmethod
    def getBoxVersion(self):
        pass;
    @abc.abstractmethod
    def getSystemTemperature(self):
        pass;
    @abc.abstractmethod
    def getIP(self):
        pass;
    @abc.abstractmethod
    def setIP(self,eth_dev,ip_info):
        pass;
    @abc.abstractmethod
    def getSystemVersion(self):
        pass;
    @abc.abstractmethod
    def getTpuData(self):
        pass;
    @abc.abstractmethod
    def getCpuRate(self):
        pass;
    @abc.abstractmethod
    def getDeviceSN(self):
        pass;
    @abc.abstractmethod
    def getSystemFan(self):
        pass
    @abc.abstractmethod
    def getSystemHardwareInfo(self):
        pass
    @abc.abstractmethod
    def getSystemMemory(self):
        pass
