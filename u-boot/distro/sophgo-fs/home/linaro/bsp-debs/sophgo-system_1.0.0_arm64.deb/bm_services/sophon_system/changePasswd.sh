#!/usr/bin/expect

set timeout -1
set UserName [lindex $argv 0]
set Password [lindex $argv 1]

spawn passwd $UserName 
expect {
	"New password" {
		send "$Password\r"
	}
	default {
		send_user "Change failed"
	}
}

expect {
	"Retype new password:" {send "$Password\r"} 
	default {send_user "Change failed!"}
	}
expect {
	"password updated successfully" {send_user "Changed Successful!!\r"} 
	default {send_user "Change failed!!"}
	}


