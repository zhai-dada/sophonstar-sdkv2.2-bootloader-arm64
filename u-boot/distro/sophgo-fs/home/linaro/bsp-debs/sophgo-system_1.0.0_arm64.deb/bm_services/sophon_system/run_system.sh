#!/bin/bash
export LD_LIBRARY_PATH=/opt/lib:$LD_LIBRARY_PATH
export PYTHONPATH=$PYTHONPATH:/opt/lib:/bm_services/sophon_system:/bm_services/sophon_system/Util

chipinfo=$(cat /proc/cpuinfo | grep "model name" | awk  'NR==1{print $4}')

ulimit -n 20480
while [ -f "/etc/systemd/system/basic.target.wants/resize-helper.service" ];
do
	echo "waiting resize finish!!!"
	sleep 1;
done

mkdir /data/log

# run OEM config reader for update OEMconfig.ini
if [ ! -f "/factory/OEMconfig.ini"   ]; then
        if [ -f "/bm_services/sophon_system/read_oem" ]; then
            sudo chmod +x /bm_services/sophon_system/read_oem
            sudo mkdir /factory
            /bm_services/sophon_system/read_oem
        fi
fi

if [ ! -d "/data/webUIStatic" ]; then

    echo "setup webUI static files"
    sudo python3 /bm_services/WebUI/setupconfig.py

fi

# ota restore backup infomation
if [  -f "/data/factory/public_ota/restore_infor.sh"  ]; then
    sudo chmod +x /data/factory/public_ota/restore_infor.sh
    /data/factory/public_ota/restore_infor.sh
    ip addr flush dev eth0
    ip addr flush dev eth1
    sudo systemctl restart networking
    sudo systemctl restart NetworkManager
    new_hosts=$(grep "127.0.1.1" /etc/hosts | awk '{print $2}')
    sudo hostnamectl set-hostname $new_hosts
    #delete ota package
    mv /data/factory/public_ota/restore_infor.sh /data/factory/public_ota/restore_infor.done

    sudo rm -rf /data/factory/public_ota/*.cmd
    sudo rm -rf /data/factory/public_ota/*.gz
    sudo rm -rf /data/factory/public_ota/*.scr
fi


echo "start system_server"
#gunicorn -b 0.0.0.0:8888 -t 500 -k gthread --thread=50 --graceful-timeout 1 --worker-connections=100 --error-logfile=/var/log/gunicorn.log sophon_system_server:app
PYTHONIOENCODING=utf-8  python3  sophon_system_server.py
