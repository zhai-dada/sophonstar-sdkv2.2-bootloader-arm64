#!/bin/bash
systemctl enable systemd-timesyncd
systemctl restart systemd-timesyncd
