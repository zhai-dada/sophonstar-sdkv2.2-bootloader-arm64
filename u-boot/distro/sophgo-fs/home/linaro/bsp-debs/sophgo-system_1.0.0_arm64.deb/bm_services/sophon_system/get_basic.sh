#!/bin/bash


ip=$(hostname -I)
mac=$(cat /sys/class/net/eth0/address)
hostname=$(hostname)
uptimeInfo=$(uptime --pretty)

chip=`cat /sys/class/thermal/thermal_zone0/temp`
board=`cat /sys/class/thermal/thermal_zone1/temp`
chip_temp=`expr $chip / 1000`
board_temp=`expr $board / 1000`

		
cpuidle=$(top -bn 1 -i -c| grep %Cpu | awk '{print $8}')

npurate=$(cat /sys/devices/platform/2000000.bmtpu/npu_usage)



echo "{ip: $ip}, {mac: $mac}, {hostname: $hostname}, {uptimeInfo: $uptimeInfo},  {boardtemperature: $board_temp}, {coretemperature: $chip_temp}, {cpuidle: $cpuidle}, {npurate: $npurate},"
